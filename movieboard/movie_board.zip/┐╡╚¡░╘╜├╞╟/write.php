<?
	if($mode=="reply") $title="��� ����";
	elseif($mode=="modify") $title="�� �����ϱ�";
	else $title="���� �� ����";

	$a_preview = str_replace(">","><font class=list_eng>",$a_preview)."&nbsp;&nbsp;";
	$a_imagebox = str_replace(">","><font class=list_eng>",$a_imagebox)."&nbsp;&nbsp;";
?>

<SCRIPT LANGUAGE="JavaScript">
<!--
function zb_formresize(obj) {
	obj.rows += 3;
}
// -->
</SCRIPT>

<table border=0 width=<?=$width?> cellsapcing=1 cellpadding=0>
<form method=post name=write action=write_ok.php onsubmit="return check_submit();" enctype=multipart/form-data><input type=hidden name=page value=<?=$page?>><input type=hidden name=id value=<?=$id?>><input type=hidden name=no value=<?=$no?>><input type=hidden name=select_arrange value=<?=$select_arrange?>><input type=hidden name=desc value=<?=$desc?>><input type=hidden name=page_num value=<?=$page_num?>><input type=hidden name=keyword value="<?=$keyword?>"><input type=hidden name=category value="<?=$category?>"><input type=hidden name=sn value="<?=$sn?>"><input type=hidden name=ss value="<?=$ss?>"><input type=hidden name=sc value="<?=$sc?>"><input type=hidden name=mode value="<?=$mode?>">
<col width=80 align=right style=padding-right:10px;height:28px class=list1></col><col class=list0 style=padding-left:10px;height:28px width=></col>
<tr class=title>
	<td colspan=2 class=title_han align=center>&nbsp;&nbsp;<?=$title?></td>
</tr>

<?=$hide_start?>
<tr>
  <td><font class=list_eng><b>Password</b></font></td>
  <td><input type=password name=password <?=size(20)?> maxlength=20 class=input></td>
</tr>

<tr>
  <td><font class=list_eng><b>Name</b></font></td>
  <td><input type=text name=name value="<?=$name?>" <?=size(20)?> maxlength=20 class=input></td>
</tr>

<tr>
  <td><font class=list_eng>E-mail</font></td>
  <td><input type=text name=email value="<?=$email?>" <?=size(40)?> maxlength=200 class=input></td>
</tr>

<tr>
  <td><font class=list_eng>Homepage</font></td>
  <td><input type=text name=homepage value="<?=$homepage?>" <?=size(40)?> maxlength=200 class=input></td>
</tr>
<?=$hide_end?>

<tr>
  <td><font class=list_eng>Option</font></td>
  <td class=list_eng>
       <?=$category_kind?>
       <?=$hide_notice_start?> <input type=checkbox name=notice <?=$notice?> value=1> �������� <?=$hide_notice_end?>
       <?=$hide_html_start?> <input type=checkbox name=use_html <?=$use_html?> value=1> HTML��� <?=$hide_html_end?>
       <input type=checkbox name=reply_mail <?=$reply_mail?> value=1> �亯���Ϲޱ�
       <?=$hide_secret_start?> <input type=checkbox name=is_secret <?=$secret?> value=1> ��б� <?=$hide_secret_end?>

<?
        if($member[no]) { //ȸ���� ���� ��Ÿ���ϴ�.
        ?>
        <?
        //�ð����
        $newTime[0]=number_format($_zbDefaultSetup[login_time]/(60*60*24));
        //�а��
        $newTime[1]=number_format((($_zbDefaultSetup[login_time]%(60*60*24))/60));
        //�ʰ��
        $newTime[2]=number_format((($_zbDefaultSetup[login_time]%(60*60*24))%60));
        ?>

        <script language="javascript">
        <!--
                var NewTime = new Date(1900, 0, 0, <?=$newTime[0]?>, <?=$newTime[1]?>, <?=$newTime[2]?>); // ��, ��, ��, �ð�, ��, ��
                var intNew,intNow;
                var strTime,strNow;
                var intExtend
                intNew = NewTime.getSeconds() + 1;
                NewTime.setSeconds(intNew);
                function TimeRoutine() {
                                intNew = NewTime.getSeconds() - 1;
                                NewTime.setSeconds(intNew);
                                setTimeout("TimeRoutine()",1000);
                }
                function StatusClock() {
                        strTime = '';
                        if(NewTime.getHours() > 0){
                                strTime += NewTime.getHours() + '�ð� ';
                        }
                        if(NewTime.getMinutes() > 0){
                                strTime += NewTime.getMinutes() + '�� ';
                        }
                        if(NewTime.getSeconds() > 0){
                                strTime += NewTime.getSeconds() + '��';
                        }
                        if (NewTime.getHours()==0 && NewTime.getMinutes()==0 && NewTime.getSeconds()==0) {
                                if(document.readyState == 'complete') {
                                        if( 'N' == 'Y' || 'N' == 'y' ) {
                                                intExtend = eval(document.all.txtExtend.innerHTML) + 1;
                                        }else {
                                                document.all.timer.innerHTML = "Ÿ�̸�����";
                                        }
                                        return;
                                }
                        }else{
                                if(document.readyState == 'complete') {
                                        document.all.timer.innerHTML = strTime ;
                                }
                                tid=window.setTimeout("StatusClock()",1000);
                        }
                }
                TimeRoutine();
                StatusClock();
        //-->
        </script>
<SCRIPT LANGUAGE="JavaScript">
function copy() {
        document.write.memo.select();
        document.execCommand("Copy");
        document.execCommand("paste");
}
</script>
        <tr>
          <td align='right' valign='bottom' width=60><font color='gray'><span style="font-size:9pt;"><b>��ȿ�ð�</b></span></font></td> 
          <td>
          <input type='checkbox' disabled>

          <!--���Ⱑ �ð�ī���õǴ� ���Դϴ�.-->
          <font color='red'><span id ='timer'></span></font>
          <!--���Ⱑ �ð�ī���õǴ� ���Դϴ�.-->

          <font color='gray'><span style="font-size:9pt;"><b>  �����ϼ���.</b> �ð��� �ʰ��ϸ� �ڵ����� �α׿����Ǿ� ���� ���ư��ϴ�.</span></font>
<input type=button accesskey=c value="Ŭ�����忡 ����(alt+c)" onClick="copy()">
          </td>
        </tr>
        <?
        }
        ?>

  </td>
</tr>

<tr valign=top>
  <td><font class=list_eng><b>����</b></font></td>
  <td><input type=text name=subject value="<?=$subject?>" <?=size(60)?> maxlength=200 style=width:99% class=input></td>
</tr>

<tr>
  <td><font class=list_eng>�帣</font></td>
  <td><input type=text name=file_name2 value="<?=$data[file_name2]?>" <?=size(62)?> maxlength=30 class=input style=width:99%></td>
</tr>
<?=$hide_sitelink1_start?>
<tr>
  <td><font class=list_eng>����<br></font></td>
  <td><input type=text name=sitelink1 <?=size(60)?> maxlength=255 class=input style=width:99%><?=$sitelink1?></td>
</tr>
<?=$hide_sitelink1_end?>
<?=$hide_sitelink2_start?>
<tr>
  <td class=list_eng>�ֿ�</font></td>
  <td><input type=text name=sitelink2 value="<?=$sitelink2?>" <?=size(20)?> maxlength=50 class=input style=width:99%></td>
</tr>
<?=$hide_sitelink2_end?>

<tr>
  <td onclick=document.write.memo.rows=document.write.memo.rows+4 style=cursor:hand><font class=list_eng>����</font> <font class=list_eng>��</font></td>
  <td style=padding-top:8px;padding-bottom:8px;><textarea name=memo <?=size2(90)?> rows=18 class=textarea style=width:99%><?=$memo?></textarea></td>
</tr>

<?=$hide_pds_start?>
<tr>
  <td><font class=list_eng>������</font></td>
  <td class=list_eng><input type=file name=file1 <?=size(50)?> maxlength=255 class=input style=width:99%> <?=$file_name1?></td>
</tr>

<?=$hide_pds_end?>

</table>

<table border=0 width=<?=$width?> cellsapcing=1 cellpadding=0>
<tr>
	<td colspan=2>
		<table border=0 cellspacing=1 cellpadding=2 width=100% height=40>
		<tr>
			<td>
				<?=$a_preview?>�̸�����</a>
				<?=$a_imagebox?>�׸�â��</a>
				&nbsp;
			</td>
			<td align=right>
				<input type=submit value="�ۼ��Ϸ�" class=submit accesskey="s">
				<input type=button value="����ϱ�" class=button onclick=history.back()>
			</td>
		</tr>
		</table>
	</td>
</tr>
</table>
<br>

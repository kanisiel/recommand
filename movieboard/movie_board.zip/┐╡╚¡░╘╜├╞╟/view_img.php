<html>
<head>
<title>VIEW POSTER</title>
</head>
<body topmargin=0 leftmargin=0 marginwidth=0 marginheight=0 oncontextmenu="return false" ondragstart="return false">
<a href=# onclick=window.close() onfocus=blur() title="Ŭ���ϸ� â�� �����ϴ�."><img src=../../<?echo $file?> border=0></a>
</body>
</html>
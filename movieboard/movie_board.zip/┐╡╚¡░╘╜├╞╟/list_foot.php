</table>
<?
	if(!eregi("Zeroboard",$a_list)) $a_list = str_replace(">","><font class=list_eng>",$a_list)."&nbsp;&nbsp;";
	if(!eregi("Zeroboard",$delete_all)) $a_delete_all = str_replace(">","><font class=list_eng>",$a_delete_all)."&nbsp;&nbsp;";
	if(!eregi("Zeroboard",$a_1_prev_page)) $a_1_prev_page = str_replace(">","><font class=list_eng>",$a_1_prev_page)."&nbsp;&nbsp;";
	if(!eregi("Zeroboard",$a_1_next_page)) $a_1_next_page = str_replace(">","><font class=list_eng>",$a_1_next_page)."&nbsp;&nbsp;";
	if(!eregi("Zeroboard",$a_write)) $a_write = str_replace(">","><font class=list_eng>",$a_write)."&nbsp;&nbsp;";
	if(!eregi("Zeroboard",$a_prev_page)) $a_prev_page = str_replace(">","><font class=list_eng>",$a_prev_page)."&nbsp;&nbsp;";
	if(!eregi("Zeroboard",$a_next_page)) $a_next_page = str_replace(">","><font class=list_eng>",$a_next_page)."&nbsp;&nbsp;";
	$print_page = str_replace("<font style=font-size:8pt>","<font class=list_eng>",$print_page);
	$print_page = str_replace("��� �˻�","<font class=list_han>��� �˻�",$print_page);
	$print_page = str_replace("���� �˻�","<font class=list_han>��� �˻�",$print_page);
?>

<script language="JavaScript">
function toggle(e) {
	if (e.style.display == "none")
		{ e.style.display = ""; }
	else 	{ e.style.display = "none"; }
	}
</script>

<table border=0 cellpadding=0 cellspacing=0 width=<?=$width?>>
<tr>
   <td class=line_plus>
   </td>
</tr>
</table>

<img src=<?=$dir?>/t.gif border=0 height=5>

<table border=0 cellpadding=0 cellspacing=0 width=<?=$width?>>
<tr valign=top>
	<td>
		<?=$a_list?><img src=<?=$dir?>/images/m_list.gif border=0></a>&nbsp;&nbsp;
		<a href=javascript:toggle(search1) onfocus=this.blur()><font class=list_eng><img src=<?=$dir?>/images/m_search.gif border=0></font></a>
		<?=$a_delete_all?><img src=<?=$dir?>/images/m_admin.gif border=0></a>
		<?=$a_1_prev_page?><img src=<?=$dir?>/images/m_prev.gif border=0></a>
		<?=$a_1_next_page?><img src=<?=$dir?>/images/m_next.gif border=0></a>
		<?=$a_write?><img src=<?=$dir?>/images/m_write.gif border=0></a>
	</td>
	<td align=right>
		<?=$a_prev_page?>[���� <?=$setup[page_num]?>��]</a></font> <?=$print_page?> <?=$a_next_page?>[���� <?=$setup[page_num]?>��]</font></a><br>
    </td>
</tr>
</table>

<div align=center id="search1" style="width:10px; z-index:1; border:0px solid #000000; background-color:; layer-background-color:; margin:0px; display: none;">

<br>
<table border=0 cellpadding=0 cellspacing=0 width=<?=$width?>>
<tr valign=top>
	<td>
	</td>
	<td align=center>
		<table border=0 cellspacing=0 cellpadding=0>
		</form>
		<form method=get name=search action=<?=$PHP_SELF?>><input type=hidden name=id value=<?=$id?>><input type=hidden name=select_arrange value=<?=$select_arrange?>><input type=hidden name=desc value=<?=$desc?>><input type=hidden name=page_num value=<?=$page_num?>><input type=hidden name=selected><input type=hidden name=exec><input type=hidden name=sn value="<?=$sn?>"><input type=hidden name=ss value="<?=$ss?>"><input type=hidden name=sc value="off"><input type=hidden name=category value="<?=$category?>">
		<tr>
			<td>
				<a href="javascript:OnOff('sn')" onfocus=blur()><img src=<?=$dir?>/name_<?=$sn?>.gif border=0 name=sn></a>&nbsp;
				<a href="javascript:OnOff('ss')" onfocus=blur()><img src=<?=$dir?>/subject_<?=$ss?>.gif border=0 name=ss></a>&nbsp;&nbsp;
				<a href="javascript:OnOff('sc')" onfocus=blur()><img src=<?=$dir?>/content_<?=$sc?>.gif border=0 name=sc></a>&nbsp;&nbsp;
			</td>
			<td><input type=text name=keyword value="<?=$keyword?>" class=input size=30></td>
			<td><input type=submit class=submit value="�˻�"></td>
			<td><input type=button class=button value="���" onclick=location.href="zboard.php?id=<?=$id?>"></td>
		</tr>
		</form>
		</table>
	</td>
</tr>
</table>
</div>
<br>
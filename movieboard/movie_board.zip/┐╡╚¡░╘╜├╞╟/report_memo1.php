<script language=javascript>
function toggleMenu(currMenu) {
                        if (document.all) {
                                thisMenu = eval("document.all." + currMenu + ".style")
                                if (thisMenu.display == "block") {
                                        thisMenu.display = "none"
                                }
                                else {
                                        thisMenu.display = "block"
                                }
                                return false
                        }
                        else {
                                return true
                        }
                }

</script>

        <a onClick="return toggleMenu('menu1')" style="cursor:hand"><font color=#000000><b>�Խù� �Ű�</b></font></a>

            <span id=menu1 style="display:none">
            <!--����� ���� �Ű� �κ�-->
            <table cellpadding=5 cellspacing=0 border=0 width=100%>
                    <tr><td align=center height=18>
                    </td></tr>
                    <tr>
                            <td width=100% bgcolor=#ffffff>
                            <B>�˸�</B>: �� �Խù��� �Ű��ϰ� �����ø� �Ʒ��� ��ư�� ���� �Ű����ֽñ� �ٶ��ϴ�. <BR>
                            <form method=post name=list action=report_memo2.php target=_new onsubmit="return confirm('�Ű��Ͻðڽ��ϱ�?')">
			    <input type=hidden name=fromno value=<?=$data[ismember]?>>
			    <input type=hidden name=tono value=<?=$member[no]?>>
                            <input type=hidden name=memofrom value="<?=$data[name]?>">
                            <input type=hidden name=memoto value=<?=$member[name]?>>
                            <input type=hidden name=memodate value="<?=$reg_date?>">
                            <input type=hidden name=memo value="<a href=javascript:opener.location.href='view.php?id=<?=$id?>&page=<?=$page?>&page_num=<?=$page_num?>&select_arrange=<?=$select_arrange?>&desc=<?=$des?>&sn=<?=$sn?>&ss=<?=$ss?>&sc=<?=$sc?>&keyword=<?=$keyword?>&no=<?=$no?>&category=<?=$category?>';window.close();opener.focus();>�Խù��� �ٷ� �̵��Ͻ÷��� ���⸦ ��������.</a>">
                            </td></tr>
                            <tr><td align=center bgcolor=#ffffff>
                            <B>����</B>: <input type=text name=whymemo size=101 style='border-color:#eeeeee' class=input >
                            </td></tr>
                            <tr><td align=center>
                            <input type=submit value="�Խù� �Ű��ϱ�"></form>
                            </td>
                    </tr>
            </table>
            <!--����� ���� �Ű� �κ�-->
            </span>
<title>:: Movie Preview ::</title>
<frameset border="0" framespacing="0" frameborder="no" rows="0,*">
	<frame name=loveleth src="preview_top.htm" scrolling=no border="0" frameborder="no" Noresize>
	<frame name=loveletm src="movie.php?link=<?=$link?>&title=<?=$title?>" scrolling=no border="0" frameborder="no">
</frameset><noframes></noframes>

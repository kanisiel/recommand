<?
$movie_data=array();
$movie_data=explode("||",$data[subject]);

$title=$movie_data[0];
$director=$movie_data[1];
$genre=$movie_data[2];
$startings=$movie_data[3];
$runtime=$movie_data[4];
$certification=$movie_data[5];

$view_src="view.php?id=$id&no=".$data[no]."&category=".$category;
?>
<?
	$subject = str_replace(">","><font class=list_han>",$subject);
	$name= str_replace(">","><font class=list_han>",$name);
    $list_mouse_over_color = "#ffffff";
?>

<tr align=center class=list<?=$coloring%2?> onMouseOver=this.style.backgroundColor='<?=$list_mouse_over_color?>' onMouseOut=this.style.backgroundColor=''>
	<td bgcolor=f5f5f5><b>Notice</b></td>
	<td bgcolor=f5f5f5 align=left nowrap><?=$hide_cart_start?><input type=checkbox name=cart value="<?=$data[no]?>"><?=$hide_cart_end?>&nbsp;<?=$reg_date?>&nbsp;<?=$insert?><?=$icon?><?=$subject?> &nbsp;<font class=list_eng style=font-size:9pt><?=$comment_num?></font></td>
        <td bgcolor=f5f5f5><?=$face_image?>&nbsp;<?=$name?></td>
</tr>
<tr>
<td background=<?=$dir?>/white.gif></td>
<td background=<?=$dir?>/white.gif></td>
<td background=<?=$dir?>/white.gif></td>
</tr>
<?$coloring++;?>
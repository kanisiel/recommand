<div align=center>
<br><br><br>

<table border=0 width=250>
<col width=80 style=padding-right:10px></col><col width=></col>
<tr class=title>
  <td align=center colspan=2 height=30><b>MEMBER LOGIN</td>
</tr>
<tr>
  <td class=list0 align=right height=26><font class=list_eng>User ID</font></td>
  <td class=list1 align=center><input type=text name=user_id size=20 maxlength=20 class=input style=width:100%></td>
</tr>
<tr>
  <td class=list0 align=right height=26><font class=list_eng>Password</font></td>
  <td class=list1 align=center><input type=password name=password size=20 maxlength=20 class=input style=width:100%></td>
</tr>
</table>
<br>
<input type=submit value="�α���" class=submit> <input type=button class=button value="����ȭ��" onclick=history.back()>
</div>
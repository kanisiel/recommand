<?

unset($s_info);
 $_srcname="$dir/noscreenshot.gif";
 $_xsize=100;
 $_ysize=100;
 $_alink="";
 /*** ������ ��Ų���� ����ϴ� �κ�.. ������ ������. ^^;; ****/
 if($data[file_name1])
 {
  $s_info = @getimagesize($data[file_name1]);

	if($s_info[2]>0&&$s_info[2]<4)
	{
		$_xsize = $s_info[0];
		if($_xsize>$_hsize) $_xsize=$_hsize;
		$_srcname = $data[file_name1];
		$_alink="<a href=javascript:void(window.open('$dir/show_pic.php?file=$data[file_name1]','$data[no]','width=$s_info[0],height=$s_info[1],resizable=yes,toolbars=no,scrollbars=auto')) onfocus=blur()>";
	}
 }

 $_x ++;
 $_temp = $_x % $_h_num;

?>
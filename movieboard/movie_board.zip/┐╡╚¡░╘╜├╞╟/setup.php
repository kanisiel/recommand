<?
if(!eregi("Zeroboard",$a_cart)) $a_cart= str_replace(">","><font class=list_han>",$a_cart)."&nbsp;";
if(!eregi("Zeroboard",$a_login)) $a_login= str_replace(">","><font class=list_han>",$a_login)."&nbsp;";
if(!eregi("Zeroboard",$a_logout)) $a_logout= str_replace(">","><font class=list_han>",$a_logout)."&nbsp;";
if(!eregi("Zeroboard",$a_setup)) $a_setup= str_replace(">","><font class=list_han>",$a_setup)."&nbsp;";
if(!eregi("Zeroboard",$a_member_join)) $a_member_join= str_replace(">","><font class=list_han>",$a_member_join)."&nbsp;";
if(!eregi("Zeroboard",$a_member_modify)) $a_member_modify= str_replace(">","><font class=list_han>",$a_member_modify)."&nbsp;";
if(!eregi("Zeroboard",$a_member_memo)) $a_member_memo= str_replace(">","><font class=list_han>",$a_member_memo)."&nbsp;";
?>
<? 
// ȸ�� ����Ʈ�� �ҷ����� �Լ� 
function point_lev($member_no) { 
global $connect, $member_table; 
if($member_no) { 
$data=mysql_fetch_array(mysql_query("select point1,point2 from $member_table where no='$member_no'"));  
$return_point1 = $data['point1']*10 + $data['point2'];  
$return_point2 = $return_point1/1000; 
$p_level1 = ceil($return_point2); 
$p_level2 = ($return_point1 + 1000) - $p_level1*1000; 
if($p_level2<"100") $p_level3 = "<font color=#cccccc>llllllllll</font>"; 
elseif($p_level2<"200") $p_level3 = "<font color=#333333>l</font><font color=#cccccc>lllllllll</font>"; 
elseif($p_level2<"300") $p_level3 = "<font color=#333333>ll</font><font color=#cccccc>llllllll</font>"; 
elseif($p_level2<"400") $p_level3 = "<font color=#333333>lll</font><font color=#cccccc>lllllll</font>"; 
elseif($p_level2<"500") $p_level3 = "<font color=#333333>llll</font><font color=#cccccc>llllll</font>"; 
elseif($p_level2<"600") $p_level3 = "<font color=#333333>lllll</font><font color=#cccccc>lllll</font>"; 
elseif($p_level2<"700") $p_level3 = "<font color=#333333>llllll</font><font color=#cccccc>llll</font>"; 
elseif($p_level2<"800") $p_level3 = "<font color=#333333>lllllll</font><font color=#cccccc>lll</font>"; 
elseif($p_level2<"900") $p_level3 = "<font color=#333333>llllllll</font><font color=#cccccc>ll</font>"; 
elseif($p_level2<"950") $p_level3 = "<font color=#333333>lllllllll</font><font color=#cccccc>l</font>"; 
else $p_level3 = "<font color=#333333>llllllllll</font>"; 
echo "<b><font color=333333>level ".$p_level1."</font></b>  ".$p_level3; 
} else { 
echo "<b>out of level</b>"; 
} 
} 
?>
<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
<tr>
	<td <?if(!$setup[use_category]) echo"align=right";?>>
        <?=$hide_cart_start?><?=$a_cart?>üũ�ڽ�</a><?=$hide_cart_end?>
		<?=$a_setup?>��������</a>
	</td>
<?=$hide_category_start?>
	<td align=right><font class=list_eng><b>Category</b> :</font> <?=$a_category?></td>
<?=$hide_category_end?>
</tr>
</table>
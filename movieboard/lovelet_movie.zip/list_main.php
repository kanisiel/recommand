<?
	$subject = str_replace(">","><font class=title><b>",$subject);
	$view_src="view.php?id=$id&no=".$data[no]."&category=".$category."&page=".$page."&divpage=".$divpage;
	$view_img="<img src='$dir/noimg.gif'>";
	if($data[file_name1]) {
		$view_img="<a href='$view_src'><img src='$data[file_name1]' border=0 height='129' width='89'></a>";}

	// ������ �����ϱ�
	$lovelet_data=array();
	$lovelet_data=explode("||",$data[memo]);

	$ll1=$lovelet_data[0]; // ����
	$ll2=$lovelet_data[1]; // �ֿ�
	$ll3=$lovelet_data[2]; // �帣
	$ll4=$lovelet_data[3]; // ���
	$ll5=$lovelet_data[4]; // �󿵽ð�
	$ll6=$lovelet_data[5]; // ������
	$ll7=$lovelet_data[6]; // ������ �Ұ���
	$ll8=$lovelet_data[7]; // ����

	// �� ��Ͽ��� ��޺����ֱ�
	if ($ll4=="grade_all") $grade="grade_all.gif";
	elseif ($ll4=="grade_12") $grade="grade_12.gif";
	elseif ($ll4=="grade_15") $grade="grade_15.gif";
	elseif ($ll4=="grade_18") $grade="grade_18.gif";
	else $grade="grade_n.gif";

	// �� ��Ͽ��� ���Ϻ����ֱ�	
	$DAY = explode("-",$ll6);
	$dd = date("w", strtotime("$ll6"));
	$week = array("��", "��", "ȭ", "��", "��", "��", "��"); 
?>

<!-- ��� �κ� ���� -->
		<th width=<?echo (100 / $list_max);?>% valign=top style="table-layout:fixed">
	<table border=0 cellspacing=0 cellpadding=0 width=100%>
		<col width=8></col><col width=100></col><col width=8></col><col width=></col><col width=8></col>
		<tr valign=top>
			<td></td>
			<td align=center valign=top>
		<table border="0" cellpadding="0" cellspacing="1" bgcolor=dddddd>
				<tr>
					<td>
				<table border="0" cellpadding="0" cellspacing="0" bgcolor="white">
                	                        <tr>
							<td align=center style='padding:3px'><?=$view_img?></td>
						</tr>
				</table></td>
				</tr>
			</table></td>
			<td></td>
			<td valign=top>
		<table border="0" cellpadding="0" cellspacing="0" width=100%>
			<col width=50></col><col width=></col>
			<tr style='padding:3 0 3 0;'>
				<td colspan=2 style='word-break:break-all;'><?=$subject?></b></font>&nbsp;<img src=<?=$dir?>/<?=$grade?> align=absmiddle></td>
			</tr>
			<tr>
				<td height="1" background="<?=$dir?>/dot.gif" colspan=2></td>
			</tr>
			<tr style='padding:3 0 3 0;'>
				<td style='word-break:break-all;' colspan=2 class=precontent>&nbsp;<? echo text_cut (stripslashes($ll7), $l_max);?></td>
			</tr>
			<tr>
				<td height="1" background="<?=$dir?>/dot.gif" colspan=2></td>
			</tr>
			<tr style='padding:3 0 3 0;' valign=top class=detail>
				<td align=right><b>����</b> :</td>
				<td style='word-break:break-all;'>&nbsp;<?=$ll1?></td>
			</tr>
			<tr>
				<td height="1" background="<?=$dir?>/dot.gif" colspan=2></td>
			</tr>
			<tr style='padding:3 0 3 0;' valign=top class=detail>
				<td align=right><b>�ֿ�</b> :</td>
				<td style='word-break:break-all;'>&nbsp;<?=$ll2?></td>
			</tr>
			<tr>
				<td height="1" background="<?=$dir?>/dot.gif" colspan=2></td>
			</tr>
			<tr style='padding:3 0 3 0;' valign=top class=detail>
				<td align=right><b>������</b> :</td>
				<td style='word-break:break-all;'>&nbsp;<? if (!$ll6) { echo "����";}
else {echo "$ll6&nbsp;($week[$dd])";}?></td>
			</tr>
			<tr>
				<td height="1" background="<?=$dir?>/dot.gif" colspan=2></td>
			</tr>
			<tr style='padding:3 0 3 0;'>
				<td align=right class=detail><b>����</b> :</td>
				<td style='word-break:break-all;'>&nbsp;<?include"$dir/starpoint2.php"?></td>
			</tr>
			<tr>
				<td height="1" background="<?=$dir?>/dot.gif" colspan=2></td>
			</tr>
		</table></td>
			<td></td>
		</tr>
	</table></th>

<?
	$temp++;
	if($temp>=$list_max)
	{echo"</tr>
	<tr height=30>
		<td colspan=$list_max></td>
	</tr><tr>";
	$temp=0;}
?>
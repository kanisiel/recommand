<meta http-equiv="imagetoolbar" content="no">

<?
if(eregi(":\/\/",$dir)||eregi("\.\.",$dir)) $dir=".";
include "$dir/module.php";
?>
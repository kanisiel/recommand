<?
 	$temp=0;
?>

<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
<!-----�� �˻� ��[�������� ������]----->
<form method=get name=search action=<?=$PHP_SELF?>> 
<input type=hidden name=page value=<?=$page?>> 
<input type=hidden name=id value=<?=$id?>> 
<input type=hidden name=select_arrange value=<?=$select_arrange?>> 
<input type=hidden name=desc value=<?=$desc?>> 
<input type=hidden name=page_num value=<?=$page_num?>> 
<input type=hidden name=selected> 
<input type=hidden name=exec> 
<input type=hidden name=sn value="off">
<input type=hidden name=ss value="on">
<input type=hidden name=sc value="on">
<input type=hidden name=category value="<?=$category?>"> 
<!-----�� �˻� ��[�������� ������]----->
	<tr height=20>
		<td width=<?=$width-208?>><?=$a_subject?><img src=<?=$dir?>/arr_sub.gif border=0 onfocus=blur()></a><?=$a_sitelink2?><img src=<?=$dir?>/arr_point.gif border=0 onfocus=blur()></a><?=$a_hit?><img src=<?=$dir?>/arr_hit.gif border=0 onfocus=blur()></a></td>
		<td align="right" width=150><input type=text name=keyword value="<?=$keyword?>" class=search size=14></td>
		<td width=28><input type=image src=<?=$dir?>/search.gif border=0 onfocus=blur()></td>
		<td width=30><?=$a_cancel?><img src=<?=$dir?>/searchc.gif border=0 onfocus=blur()></a></td>
	</tr></form>
	<tr height=25>
		<td colspan=4></td>
	</tr>
</table>

<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
	<tr>
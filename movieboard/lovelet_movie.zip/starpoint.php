<?
//�ڸ�Ʈ�κ��� ����Ʈ�� ���

$cmtpoint=0;
$totalcomment=0;
$myquery=mysql_query("select * from $t_comment"."_$id where parent='$data[no]' order by reg_date desc ");

while($comment_p = mysql_fetch_array($myquery)  ) {
	$point1=$comment_p[memo];
	$point2=explode("||",$point1);
	if (intval($point2[1])!=0) { 
		$cmtpoint=$cmtpoint+intval($point2[1]); $totalcomment++;} //��� ���� ������ �ذ͵鿡�� �ݿ�
}


echo "<table width='100' height='100' border=0  cellspacing=0 cellpadding=0 background='$dir/point_bg.gif'><tr height='10'><td></td></tr><tr height='30'><td align='center'><table border=0 cellspacing=0 cellpadding=0 height='30'><tr><td align=center'>";

$countp="<span style='color:#dddddd'>���� ����</span>";	// ���ڰ� ���� ���


if ($totalcomment!=0) {
$cmt=$cmtpoint;
$cmtpoint=intval($cmtpoint/$totalcomment);
$cmtpoint2=number_format($cmt/$totalcomment,2);
$countp="<span style='color:#bbbbbb'><b>".$totalcomment."</b>�� ��</span>";
echo "<span style='font-size:30px;color:#FF9C3D;line-height:100%'>".$cmtpoint2."</td></tr></table></td></tr>";
} else {
echo "<span style='font-size:30px;color:#DDDDDD;line-height:100%'>0.00</td></tr></table></td></tr>";
}

echo "<tr height='25'><td align='center'>";

$a=(int)($cmtpoint/2);
for($i=1;$i<=$a;$i++) {
echo "<img src='$dir/star_2.gif' align='absmiddle'>";
}
if($cmtpoint%2 ==1) {
$b=1;
echo "<img src='$dir/star_1.gif' align='absmiddle'>";
} else {
$b=0;
}
$c=5-$a-$b;
for($i=1;$i<=$c;$i++) {
echo "<img src='$dir/star_0.gif' align='absmiddle'>";
}

echo "</td></tr>";

echo "<tr height='25'><td align='center'>".$countp."</td></tr></table>";
?>
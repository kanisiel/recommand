<html>

<head>
<title>Skin Information..</title>
<style>
body,table {COLOR: #555555; FONT-FAMILY: verdana,����; FONT-SIZE: 12px;letter-spacing:-1px;}
A:link {COLOR: #555555; TEXT-DECORATION: none}
A:visited {COLOR: #555555; TEXT-DECORATION: none}
A:active {COLOR: #555555; TEXT-DECORATION: none}
A:hover {COLOR: #ff0b5b; TEXT-DECORATION: underline;}
BODY
{scrollbar-face-color:#ffffff;
scrollbar-shadow-color:#3788ae;
scrollbar-highlight-color: #3788ae;
scrollbar-3dlight-color: #ffffff;
scrollbar-darkshadow-color: #ffffff;
scrollbar-track-color: #ffffff;
scrollbar-arrow-color: #3788ae;
}
</style>
<script language="javascript">
    function thisClose()
   {
      top.window.opener = top;
      top.window.open('','_parent','');
      top.window.close();
    }
</script>
</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" marginwidth="0" marginheight="0" leftmargin="10" topmargin="10">
<table border="0" cellpadding="0" cellspacing="1" width="310" bgcolor=#dddddd>
<col width=90></col><col width=></col>
	<tr height='30'>
		<td align=center bgcolor=#eeeeee><b>�� Ų ��</b></td>
		<td bgcolor=#ffffff style='padding-left:10px'>��ȭ�Խ��� ��Ų</td>
	</tr>
	<tr height='30'>
		<td align=center bgcolor=#eeeeee><b>�� ��</b></td>
		<td bgcolor=#ffffff style='padding-left:10px'>v 3.0 Lite</td>
	</tr>
	<tr height='30'>
		<td align=center bgcolor=#eeeeee><b>�ֱټ�����</b></td>
		<td bgcolor=#ffffff style='padding-left:10px'>2009.03.01</td>
	</tr>
	<tr height='30'>
		<td align=center bgcolor=#eeeeee><b>�� �� ��</b></td>
		<td bgcolor=#ffffff style='padding-left:10px'>���귿 / happy0524@korea.com</td>
	</tr>
	<tr height='30'>
		<td align=center bgcolor=#eeeeee><b>�� ��</b></td>
		<td bgcolor=#ffffff style='padding-left:10px'><a href='http://www.lovelet.com/bbs/zboard.php?id=qna' target='_blank'>���귿����</a></td>
	</tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" width="310">
	<tr height='20'>
		<td align=right style='padding-top:10px'><a href="javascript:thisClose();"><img src=close.gif border=0></a></td>
	</tr>
</table>
</body>
</html>



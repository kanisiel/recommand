<?
if(eregi(":\/\/",$dir)||eregi("\.\.",$dir)) $dir ="./";
?>


<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
	<tr height=50>
		<td></td>
	</tr>
	<tr>
		<td align=center>

<table border=0 width=300 cellspacing=0 cellpadding=0>
<form>
	<tr height=2>
		<td bgcolor=dddddd></td>
	</tr>
	<tr>
		<td align=center height=30><b>����</b></td>
	</tr>
	<tr height=1>
		<td bgcolor=dddddd></td>
	</tr>
	<tr style='padding-top:10px;padding-bottom:10px;line-height:150%'>
		<td align=center><?echo $message;?></td>
	</tr>

<? if(!$url) { ?>
	<tr height=1>
		<td bgcolor=dddddd></td>
	</tr>
	<tr height=8>
		<td></td>
	</tr>
	<tr height=20>
		<td align=right><a href=javascript:void(history.back()) onfocus='this.blur()'><img src=<?=$dir?>/cancel.gif border=0 alt=���></a></td>
	</tr>

<? } else { ?>
	<tr height=1>
		<td bgcolor=dddddd></td>
	</tr>
	<tr height=8>
		<td></td>
	</tr>
	<tr height=20>
		<td align=center><a href=# onclick=location.href="<?echo $url;?>" onfocus=blur()><img src=<?=$dir?>/submit.gif></a></td>
	</tr>
<? } ?>
</form>
</table></td>
	</tr>
	<tr height=50>
		<td></td>
	</tr>
</table>
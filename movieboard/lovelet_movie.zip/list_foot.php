	</tr>
</table>

<?
/**************************************
 * ������ ��Ÿ�� ���� (by Lovelet.com)
 **************************************/
$print_page2="";
$show_page_num=$setup[page_num]; // �ѹ��� ���� ������ ����
$start_page=(int)(($page-1)/$show_page_num)*$show_page_num;
$i=1;

$a_prev_page2 = "<table cellspacing=0 cellpadding=0 border=0 style='font-family:verdana;font-size:10px;'><tr align=center>";
$a_next_page2 = "</tr></table>";

if($page>$show_page_num) {
$prev_page=$start_page;
$a_prev_page2.="<table cellspacing=0 cellpadding=0 border=0 style='font-family:verdana; font-size:10px;'><tr align=center><td style='padding:3 3 3 3' nowrap><a onfocus=blur() href='$PHP_SELF?id=$id&page=1&select_arrange=$select_arrange&desc=$desc&category=$category&sn=$sn&ss=$ss&sc=$sc&keyword=$keyword&sn1=$sn1&divpage=$divpage'><img src=$dir/prev_1_arrow.gif align=absmiddle></a></td><td style='padding:3 8 3 3' nowrap><a onfocus=blur() href='$PHP_SELF?id=$id&page=$prev_page&select_arrange=$select_arrange&desc=$desc&category=$category&sn=$sn&ss=$ss&sc=$sc&keyword=$keyword&sn1=$sn1&divpage=$divpage'><img src=$dir/prev_arrow.gif align=absmiddle></a></td>";
$prev_page_exists = true;
}

while($i+$start_page<=$total_page&&$i<=$show_page_num) {
$move_page=$i+$start_page;
if($page==$move_page) $print_page2.="<td style='padding:3 6 3 6' bgcolor='#79a536'><font color=ffffff><b>$move_page</b></font></td>";
else $print_page2.="<td style='padding:3 6 3 6'><a onfocus=blur() href='$PHP_SELF?id=$id&page=$move_page&select_arrange=$select_arrange&desc=$desc&category=$category&sn=$sn&ss=$ss&sc=$sc&keyword=$keyword&sn1=$sn1&divpage=$divpage'>$move_page</a></td>";
$i++;
}

if($total_page>$move_page) {
$next_page=$move_page+1;
$a_next_page2="<td style='padding:3 3 3 8' nowrap><a onfocus=blur() href='$PHP_SELF?id=$id&page=$next_page&select_arrange=$select_arrange&desc=$desc&category=$category&sn=$sn&ss=$ss&sc=$sc&keyword=$keyword&sn1=$sn1&divpage=$divpage'><img src=$dir/next_arrow.gif align=absmiddle></a></td><td style='padding:3 3 3 3' nowrap><a onfocus=blur() href='$PHP_SELF?id=$id&page=$total_page&select_arrange=$select_arrange&desc=$desc&category=$category&sn=$sn&ss=$ss&sc=$sc&keyword=$keyword&sn1=$sn1&divpage=$divpage'><img src=$dir/next_1_arrow.gif align=absmiddle></a></td></tr></table>";
$next_page_exists = true;
}
?>

<table border=0 cellpadding=0 cellspacing=0 width=<?=$width?>>
	<tr height="1">
		<td bgcolor="#dddddd"></td>
	</tr>
	<tr height=8>
		<td></td>
	</tr>
	<tr height="20">
		<td>
	<table border=0 cellspacing=0 cellpadding=0 width=100% height="20">
		<tr>
			<td width=50%><?=$hide_category_start?><?=$a_category?><?=$hide_category_end?></td>
			<td align=right width=50%><?=$a_write?><img src=<?=$dir?>/l_write.gif border=0></a></td>
		</tr>
	</table></td>
	</tr>
	<tr height="18">
		<td align=center><?=$a_prev_page2?><?=$print_page2?><?=$a_next_page2?></td>
	</tr>
</table>

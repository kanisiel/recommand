<script type="text/javascript" src="<?=$dir?>/js/prototype.js"></script>
<script type="text/javascript" src="<?=$dir?>/js/scriptaculous.js?load=effects,builder"></script>
<script type="text/javascript" src="<?=$dir?>/js/lightbox.js"></script>
<SCRIPT LANGUAGE="JavaScript"> 
<!-- 
function view(){ 
    var v = document.getElementById("v"); 

    if(v.style.display=="none"){ 
        v.style.display =""; 
    }else{ 
        v.style.display ="none"; 
    } 
} 
--> 
</script> 

<link rel="stylesheet" href="<?=$dir?>/css/lightbox.css" type="text/css" media="screen" />

<? include "$dir/value.php3"; ?>

<?
        if(eregi("\.jpg|\.png|\.gif|\.jpeg",$data['file_name1'])&&@file_exists($data['file_name1'])) {
        $screenshot1 = $data['file_name1'];
        $image_info = @getimagesize($screenshot1);
}
        else {
                $screenshot1="$dir/noimg2.gif";
        }


	// ������ �����ϱ�
	$lovelet_data=array();
	$lovelet_data=explode("||",$data[memo]);

	$ll1=$lovelet_data[0]; // ����
	$ll2=$lovelet_data[1]; // �ֿ�
	$ll3=$lovelet_data[2]; // �帣
	$ll4=$lovelet_data[3]; // ���
	$ll5=$lovelet_data[4]; // �󿵽ð�
	$ll6=$lovelet_data[5]; // ������
	$ll7=$lovelet_data[6]; // ������ �Ұ���
	$ll8=$lovelet_data[7]; // ����


	// �� ��Ͽ��� ��޺����ֱ�
	if ($ll4=="grade_all") $grade="grade_all.gif";
	elseif ($ll4=="grade_12") $grade="grade_12.gif";
	elseif ($ll4=="grade_15") $grade="grade_15.gif";
	elseif ($ll4=="grade_18") $grade="grade_18.gif";
	else $grade="grade_n.gif";


	// �� ��Ͽ��� ���Ϻ����ֱ�	
	$DAY = explode("-",$ll6);
	$dd = date("w", strtotime("$ll6"));
	$week = array("��", "��", "ȭ", "��", "��", "��", "��"); 


$totalcomment=0;
$myquery=mysql_query("select * from $t_comment"."_$id where parent='$data[no]' order by reg_date desc" );

while($comment_p = mysql_fetch_array($myquery) )
{
	$point1=$comment_p[memo];
	$point2=explode("||",$point1);
	if (intval($point2[1])!=0) { 
		$totalcomment++;} //��� ���� ������ �ذ͵鿡�� �ݿ�
}
?>

<table cellspacing=0 cellpadding=0 width=<?=$width?> style="table-layout:fixed">
	<col width=200></col><col width=></col>
	<tr style='padding:0 0 8 0;'>
		<td valign=top>
	<table cellspacing=0 cellpadding=0 width=100%>
		<tr>
			<td align=center>
		<table border="0" cellpadding="0" cellspacing="1" bgcolor=dddddd>
			<tr>
				<td>
			<table border="0" cellpadding="0" cellspacing="0" bgcolor="white" width=100%>
				<tr>
					<td align=center style='padding:4px'><a href="<?=$screenshot1?>" rel="lightbox" title="<?=$subject?>"><img src="<?=$screenshot1?>" name=zb_target_resize border=0 height=218 width=150></a></td>
				</tr>
			</table></td>
			</tr>
		</table></td>
		</tr>
	</table></td>
		<td valign=top>
	<table cellspacing=0 cellpadding=0 width=100% border=0>
		<tr style='word-break:break-all;' height=30>
			<td><b><font color=555555><?=$subject?></font></b>&nbsp;&nbsp;<img src=<?=$dir?>/<?=$grade?> align=absmiddle><?=$hide_category_start?><font color=888888> | <?=$category_name?></font><?=$hide_category_end?></td>
		</tr>
		<tr height=1>
			<td bgcolor='#dddddd'></td>
		</tr>
		<tr height=5>
			<td></td>
		</tr>
		<tr>
			<td>
		<table cellspacing=0 cellpadding=0 width=100% border=0 style="table-layout:fixed">
		<col width=></col><col width=130></col>
			<tr>
				<td>
			<table cellspacing=0 cellpadding=0 width=100% border=0>
				<tr style='word-break:break-all;' height='20'>
					<td class=detailv><b>�� �� :</b>&nbsp;<?=$ll1?></td>
				</tr>
				<tr style='word-break:break-all;' height='20'>
					<td class=detailv><b>�� �� :</b>&nbsp;<?=$ll2?></td>
				</tr>
				<tr style='word-break:break-all;' height='20'>
					<td class=detailv><b>�� �� :</b>&nbsp;<?=$ll3?></td>
				</tr>
				<tr style='word-break:break-all;' height='20'>
					<td class=detailv><b>�󿵽ð� :</b>&nbsp;<? if (!$ll5) { echo "����";} else {echo "$ll5"."��";}?></td>
				</tr>
				<tr style='word-break:break-all;' height='20'>
					<td class=detailv><b>������ :</b>&nbsp;<? if (!$ll6) { echo "����";} else {echo "$ll6&nbsp;($week[$dd])";}?></td>
				</tr>
<? if (!$data[sitelink1] || $data[sitelink1]=='http://') { echo "";} else { echo "
				<tr style='word-break:break-all;' height='20'>
					<td class=detailv><b>Ȩ������ :</b>&nbsp;<a href=".$data[sitelink1]." target=_blank>".$data[sitelink1]."</a></td>
				</tr>
";} ?>
			</table></td>
				<td align='center' valign='top' style='padding:20 0 0 0;'><?include"$dir/starpoint.php"?></td>
			</tr>
			<tr>
				<td colspan='2'>

			<table cellspacing=0 cellpadding=0 width=100%>
				<tr height=20>
					<td></td>
				</tr>
				<tr style='word-break:break-all;' height=22>
					<td class=detailv><b>�ó�ý� (Synopsis)</b></td>
				</tr>
				<tr height=1>
					<td bgcolor='#dddddd'></td>
				</tr>
				<tr height=5>
					<td></td>
				</tr>
				<tr style='word-break:break-all;'>
					<td class=vpcontent><b><?=$ll7?></b></td>
				</tr>
				<tr height=10>
					<td></td>
				</tr>
				<tr style='word-break:break-all;'>
					<td class=vcontent><?=stripslashes($ll8)?></td>
				</tr>
				<tr height=5>
					<td></td>
				</tr>
			</table></td>
			</tr>
		</table></td>
		</tr>
	</table></td>
	</tr>
	<tr height='1'>
		<td background='<?=$dir?>/dot.gif' colspan='2'></td>
	</tr>		

	<tr>
		<td colspan='2'>
	<table cellspacing=0 cellpadding=0 width=100% border='0'>
		<tr style='padding:16 20 6 20' bgcolor=f6f6f6>
			<td>
		<table cellspacing=0 cellpadding=0 width=100%>
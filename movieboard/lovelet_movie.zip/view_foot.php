		</table></td>
		</tr>
	</table></td>
	</tr>
</table>

<table cellspacing=0 cellpadding=0 width=<?=$width?>>
	<col width=50%></col><col width=50%></col>
	<tr height=20 style='padding-top:8px;'>
		<td><?=$a_list?><img src=<?=$dir?>/l_list.gif></a><?=$hide_prev_start?>
<?=$a_prev?><img src=<?=$dir?>/l_prev.gif></a><?=$hide_prev_end?><?=$hide_next_start?><?=$a_next?><img src=<?=$dir?>/l_next.gif></a>
<?=$hide_next_end?></td>
		<td align=right><?=$a_modify?><img src=<?=$dir?>/l_modify.gif border=0></a><?=$a_delete?><img src=<?=$dir?>/l_delete.gif></a><?=$a_write?><img src=<?=$dir?>/l_write.gif border=0></a></td>
	</tr>
</table>
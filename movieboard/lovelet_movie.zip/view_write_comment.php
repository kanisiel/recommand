<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>

function m_memo_onkeyup() {
cal_byte(write.m_memo.value);
}

function cal_byte(aquery) {
var tmpStr;
var temp=0;
var onechar;
var tcount;
tcount = 0;
tmpStr = new String(aquery);
temp = tmpStr.length;
for (k=0;k<temp;k++) {
onechar = tmpStr.charAt(k);
if (escape(onechar) =='%0D') {
}
else if (escape(onechar).length > 4) {
tcount += 2;
}
else {
tcount++;
}
}
write.txtbyte.value = tcount;
if(tcount><?=$c_max*2?>) {
reserve = tcount-<?=$c_max*2?>;
alert("<?=$c_max*2?>����Ʈ �� "+reserve+"����Ʈ�� �ʰ��Ǿ����ϴ�.\r\n�ʰ��� �κ��� �ڵ����� �����˴ϴ�."); 
nets_check(write.m_memo.value);
return;
} 
}

function nets_check(aquery) {
var tmpStr;
var temp=0;
var onechar;
var tcount;
tcount = 0;
tmpStr = new String(aquery);
temp = tmpStr.length;
for(k=0;k<temp;k++) {
onechar = tmpStr.charAt(k);
if(escape(onechar).length > 4) {
tcount += 2;
}
else {
// ���Ͱ��� �������� ��(\r\n)�� �ι�����Ǵµ� ù��° ��(\n)�� �������� tcount�� ������Ű�� �ʴ´�.
if(escape(onechar)=='%0A') {
}
else {
tcount++;
}
}
if(tcount><?=$c_max*2?>) {
tmpStr = tmpStr.substring(0,k);
break;
}
}
write.m_memo.value = tmpStr;
cal_byte(tmpStr);
}

</SCRIPT>


<SCRIPT LANGUAGE="JavaScript">
function givestarpoint() {
document.write.memo.value=document.write.m_memo.value+"||"+document.write.point.value;
}
</SCRIPT>

			<tr>
				<td>
			<table cellpadding=0 cellspacing=0 width=100%>
<!-----�ڸ�Ʈ �ۼ� ��[�������� ������]----->
<form method=post name=write action="comment_ok.php" enctype=multipart/form-data>
<input type=hidden name=page value=<?=$page?>>
<input type=hidden name=id value=<?=$id?>>
<input type=hidden name=no value=<?=$no?>>
<input type=hidden name=memo>
<input type=hidden name=select_arrange value=<?=$select_arrange?>>
<input type=hidden name=desc value=<?=$desc?>>
<input type=hidden name=page_num value=<?=$page_num?>>
<input type=hidden name=keyword value="<?=$keyword?>">
<input type=hidden name=category value="<?=$category?>">
<input type=hidden name=sn value="<?=$sn?>">
<input type=hidden name=ss value="<?=$ss?>">
<input type=hidden name=sc value="<?=$sc?>">
<input type=hidden name=mode value="<?=$mode?>">
<!-----�ڸ�Ʈ �ۼ� ��[�������� ������]----->
				<tr height=25>
					<td>Name : <?=$c_name?><?=$hide_c_password_start?>&nbsp;&nbsp;&nbsp;Password : <input type=password name=password maxlength=30 class=input><?=$hide_c_password_end?></td>
				</tr>
				<tr>
					<td>
				<table cellpadding=0 cellspacing=0 width=100%>
					<tr>
						<td onchange="givestarpoint()"><textarea name=m_memo cols="24" rows="15" style="overflow-y:auto; overflow-x:hidden;" class=ctextarea onkeyup="return m_memo_onkeyup()" onfocus="this.value='';this.onfocus='null';" onchange="givestarpoint()">�������� �Է��Ͻð�, ������ �������ּ���.</textarea></td>
					</tr>
					<tr height=30>
						<td>
					<table cellpadding=0 cellspacing=0 width=100%>
						<col width=50%></col><col width=50%></col>
						<tr height=30>
							<td><select name="point" onchange="givestarpoint()">
			<option value="0" selected>�� ��ȭ�� �����ּ���.</option>
			<option value="1">��</option>
			<option value="2">��</option>
			<option value="3">�ڡ�</option>
			<option value="4">�ڡ�</option>
			<option value="5">�ڡڡ�</option>
			<option value="6">�ڡڡ�</option>
			<option value="7">�ڡڡڡ�</option>
			<option value="8">�ڡڡڡ�</option>
			<option value="9">�ڡڡڡڡ�</option>
			<option value="10">�ڡڡڡڡ�</option>
			</select></td>
							<td align=right><input type="text" name=txtbyte size="2" value=0 class="byte" readonly> / <?=$c_max*2?> Byte</td>
						</tr>
						<tr height=5>
							<td colspan=2></td>
						</tr>
						<tr height=20>
							<td align=right colspan=2><input type=image src=<?=$dir?>/submit.gif border=0 align=absmiddle accesskey="s"></td>
						</tr>
					</table></td>
					</tr>
				</table></td>
				</tr></form>
				<tr height=5>
					<td></td>
				</tr>
			</table></td>
			</tr>
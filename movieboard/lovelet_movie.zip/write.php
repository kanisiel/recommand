<? include "$dir/module.php"; ?>

<?
	// ������ �����ϱ�
	$lovelet_data=array();
	$lovelet_data=explode("||",$data[memo]);

	$ll1=$lovelet_data[0]; // ����
	$ll2=$lovelet_data[1]; // �ֿ�
	$ll3=$lovelet_data[2]; // �帣
	$ll4=$lovelet_data[3]; // ���
	$ll5=$lovelet_data[4]; // �󿵽ð�
	$ll6=$lovelet_data[5]; // ������
	$ll7=$lovelet_data[6]; // ������ �Ұ���
	$ll8=$lovelet_data[7]; // ����
?>

<SCRIPT LANGUAGE="JavaScript">
function changeinfo()
{
for(i=0;i<write.ll4.length;i++) {
	if(write.ll4[i].checked) {
		write.ll4.value = write.ll4[i].value;
	}
}
document.write.memo.value="";
document.write.memo.value=document.write.ll1.value+"||"+document.write.ll2.value+"||"+document.write.ll3.value+"||"+document.write.ll4.value+"||"+document.write.ll5.value+"||"+document.write.ll6.value+"||"+document.write.ll7.value+"||"+document.write.ll8.value;
}
</script>

<table cellspacing=0 cellpadding=0 width=<?=$width?>>
<!-----�� �ۼ� ��[�������� ������]----->
<form method=post name=write action=write_ok.php enctype=multipart/form-data onsubmit="return check_submit();">
<input type=hidden name=page value=<?=$page?>>
<input type=hidden name=id value=<?=$id?>>
<input type=hidden name=no value=<?=$no?>>
<input type=hidden name=select_arrange value=<?=$select_arrange?>>
<input type=hidden name=desc value=<?=$desc?>>
<input type=hidden name=page_num value=<?=$page_num?>>
<input type=hidden name=keyword value="<?=$keyword?>">
<input type=hidden name=category value="<?=$category?>">
<input type=hidden name=sn value="<?=$sn?>">
<input type=hidden name=ss value="<?=$ss?>">
<input type=hidden name=sc value="<?=$sc?>">
<input type=hidden name=mode value="<?=$mode?>">
<input type=hidden name=memo value="<?=$memo?>" maxlength=1000> 
<input type=hidden name=use_html checked <?=$use_html?> value=2>
<!-----�� �ۼ� ��[�������� ������]----->
	<tr height=30>
		<td><b>���� �� ��ȭ..</b></td>
	</tr>
	<tr height=2>
		<td bgcolor=#cccccc></td>
	</tr>
</table>

<?=$hide_start?>
<table cellspacing=0 cellpadding=0 width=<?=$width?>>
	<tr height=20>
		<td></td>
	</tr>
	<tr>
		<td align=right>
	<table cellspacing=0 cellpadding=0 width=230>
		<col width=80></col><col width=></col>
		<tr height=22>
			<td align=right class=detail><b>�̸� |</b>&nbsp;</td>
			<td><input type=text name=name value="<?=$name?>" maxlength=100 class=input4></td>
		</tr>
		<tr height=22>
			<td align=right class=detail><b>��й�ȣ |</b>&nbsp;</td>
			<td><input type=password name=password maxlength=100 class=input4></td>
		</tr>
		<tr height=22>
			<td align=right class=detail><b>���ڿ��� |</b>&nbsp;</td>
			<td><input type=text name=email value="<?=$email?>" maxlength=100 class=input4></td>
		</tr>
		<tr height=22>
			<td align=right class=detail><b>Ȩ������ |</b>&nbsp;</td>
			<td><input type=text name=homepage value="<?=$homepage?>" maxlength=100 class=input4></td>
		</tr>
	</table></td>
	</tr>
</table>
<?=$hide_end?>


<table cellspacing=0 cellpadding=0 width=<?=$width?>>
	<col width=50%></col><col width=50%></col>
	<tr style='padding:20 0 5 0;'>
		<td colspan=2>
	<table cellspacing=0 cellpadding=0 width=100%>
		<col width=80></col><col width=></col>
		<tr>
			<td align=right>���� |&nbsp;</td>
			<td><input type=text name=subject value="<?=$subject?>" <?=size(30)?> maxlength=200 class=input2 style='width:50%;'>&nbsp;(�з� : <?=$category_kind?>)</td>
		</tr>
	</table></td>
	</tr>
	<tr style='padding:5 0 5 0;'>
		<td colspan=2>
	<table cellspacing=0 cellpadding=0 width=100%>
		<col width=80></col><col width=></col>
		<tr>
			<td align=right>���� |&nbsp;</td>
			<td><input type=text name=ll1 value="<?=$ll1?>" <?=size(30)?> maxlength=200 class=input2 style='width:50%;' onchange="changeinfo();"></td>
		</tr>
	</table></td>
	</tr>
	<tr style='padding:5 0 5 0;'>
		<td colspan=2>
	<table cellspacing=0 cellpadding=0 width=100%>
		<col width=80></col><col width=></col>
		<tr>
			<td align=right>�ֿ� |&nbsp;</td>
			<td><input type=text name=ll2 value="<?=$ll2?>" <?=size(30)?> maxlength=200 class=input2 style='width:100%;' onchange="changeinfo();"></td>
		</tr>
	</table></td>
	</tr>
	<tr style='padding:5 0 5 0;'>
		<td>
	<table cellspacing=0 cellpadding=0 width=100%>
		<col width=80></col><col width=></col>
		<tr>
			<td align=right>�帣 |&nbsp;</td>
			<td><input type=text name=ll3 value="<?=$ll3?>" <?=size(30)?> maxlength=200 class=input2 style='width:100%;' onchange="changeinfo();"></td>
		</tr>
	</table></td>
		<td>
	<table cellspacing=0 cellpadding=0 width=100%>
		<col width=80></col><col width=></col>
		<tr>
			<td align=right>������� |&nbsp;</td>
			<td onchange="changeinfo();"><input type=radio name=ll4 value='grade_all' <? if($ll4=="grade_all") echo "checked"; ?> onchange="changeinfo();">&nbsp;&nbsp;<img src=<?=$dir?>/grade_all.gif alt='��ü������'>&nbsp;&nbsp;<input type=radio name=ll4 value='grade_12' <? if($ll4=="grade_12") echo "checked"; ?>>&nbsp;&nbsp;<img src=<?=$dir?>/grade_12.gif alt='�� 12�� �̻������'>&nbsp;&nbsp;<input type=radio name=ll4 value='grade_15' <? if($ll4=="grade_15") echo "checked"; ?>>&nbsp;&nbsp;<img src=<?=$dir?>/grade_15.gif alt='�� 15�� �̻������'>&nbsp;&nbsp;<input type=radio name=ll4 value='grade_18' <? if($ll4=="grade_18") echo "checked"; ?>>&nbsp;&nbsp;<img src=<?=$dir?>/grade_18.gif alt='�� 18�� �̻������'></td>
		</tr>
	</table></td>
	</tr>
	<tr style='padding:5 0 5 0;'>
		<td>
	<table cellspacing=0 cellpadding=0 width=100%>
		<col width=80></col><col width=></col>
		<tr>
			<td align=right>�󿵽ð� |&nbsp;</td>
			<td><input type=text name=ll5 value="<?=$ll5?>" <?=size(3)?> maxlength=4 class=input2 onchange="changeinfo();">&nbsp;(���� : ��)</td>
		</tr>
	</table></td>
		<td>
	<table cellspacing=0 cellpadding=0 width=100%>
		<col width=80></col><col width=></col>
		<tr>
			<td align=right>������ |&nbsp;</td>
			<td><input type=text name=ll6 value="<?=$ll6?>" <?=size(9)?> maxlength=10 class=input2 onchange="changeinfo();">&nbsp;(���� : <?=date('Y') ?>-02-09)</td>
		</tr>
	</table></td>
	</tr>
<?=$hide_sitelink1_start?>
	<tr style='padding:5 0 5 0;'>
		<td colspan=2>
	<table cellspacing=0 cellpadding=0 width=100%>
		<col width=80></col><col width=></col>
		<tr>
			<td align=right>���Ļ���Ʈ |&nbsp;</td>
			<td><input type=text name=sitelink1 value="<?=$sitelink1?>" maxlength=200 style='width:100%;' class=input2></td>
		</tr>
	</table></td>
	</tr>
<?=$hide_sitelink1_end?>
<?=$hide_pds_start?>
	<tr style='padding:5 0 5 0;'>
		<td colspan=2>
	<table cellspacing=0 cellpadding=0 width=100%>
		<col width=80></col><col width=></col>
		<tr>
			<td align=right>��ȭ������ |&nbsp;</td>
			<td><input type=file name=file1 maxlength=255 style='width:100%;' class=input2><?=$file_name1?></td>
		</tr>
	</table></td>
	</tr>
<?=$hide_pds_end?>
	<tr style='padding:5 0 5 0;'>
		<td colspan=2>
	<table cellspacing=0 cellpadding=0 width=100%>
		<col width=80></col><col width=></col>
		<tr>
			<td align=right>���Ұ� |&nbsp;</td>
			<td><input type=text name=ll7 value="<?=$ll7?>" <?=size(30)?> maxlength=200 class=input2 style='width:100%;' onchange="changeinfo();"></td>
		</tr>
	</table></td>
	</tr>
	<tr style='padding:5 0 5 0;'>
		<td colspan=2>
	<table cellspacing=0 cellpadding=0 width=100%>
		<col width=80></col><col width=></col>
		<tr>
			<td align=right valign=top>�ó�ý� |&nbsp;</td>
			<td><textarea name=ll8 rows=12 class=textarea onchange="changeinfo();"><?=stripslashes($ll8)?></textarea></td>
		</tr>
	</table></td>
	</tr>
</table>

<table cellspacing=0 cellpadding=0 width=<?=$width?>>
	<tr height=1>
		<td bgcolor=#dddddd></td>
	</tr>
	<tr height=8>
		<td></td>
	</tr>
	<tr height="20">
		<td align=right><input type=image onmouseover="changeinfo();" src=<?=$dir?>/submit.gif accesskey="s" onfocus='this.blur()' alt=Ȯ��><a href=javascript:void(history.back()) onfocus='this.blur()'><img src=<?=$dir?>/cancel.gif alt=���></td>
	</tr></form>
</table>
<?
//�ڸ�Ʈ�κ��� ����Ʈ�� ���

$cmtpoint=0;
$totalcomment=0;
$myquery=mysql_query("select * from $t_comment"."_$id where parent='$data[no]' order by reg_date desc ");

while($comment_p = mysql_fetch_array($myquery)  ) {
	$point1=$comment_p[memo];
	$point2=explode("||",$point1);
	if (intval($point2[1])!=0) { 
		$cmtpoint=$cmtpoint+intval($point2[1]); $totalcomment++;} //��� ���� ������ �ذ͵鿡�� �ݿ�
}


$userrating="&nbsp;&nbsp;<font class=detail><b>0.00</b>&nbsp;/ 10.0</font>";
if ($totalcomment!=0) {
$cmt=$cmtpoint;
$cmtpoint=intval($cmtpoint/$totalcomment);
$cmtpoint2=number_format($cmt/$totalcomment,2);
$userrating="&nbsp;&nbsp;<font class=detail><b>".$cmtpoint2."</b>&nbsp;/ 10.0</font>";
 }
$a=(int)($cmtpoint/2);
for($i=1;$i<=$a;$i++) {
echo "<img src='$dir/star_2.gif' align='absmiddle'>";
}
if($cmtpoint%2 ==1) {
$b=1;
echo "<img src='$dir/star_1.gif' align='absmiddle'>";
} else {
$b=0;
}
$c=5-$a-$b;
for($i=1;$i<=$c;$i++) {
echo "<img src='$dir/star_0.gif' align='absmiddle'>";
}
echo "$userrating";
?>
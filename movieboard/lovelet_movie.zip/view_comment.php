<?
	//�ڸ�Ʈ �ʵ� ó��
	$pointmem=explode("||",$c_memo);
	if($pointmem[1]==0) {
		$lvt_point="---";
	}
	else {
		$lvt_point=$pointmem[1].".0";
	}
	if ($cmt_starpoint==NULL) $cmt_starpoint=0;	//���� �ڸ�Ʈ�� ȣȯ�� ����..
	$cmt_memo=nl2br($pointmem[0]);


	$date="<font class=ver7>".date("Y-m-d", $c_data[reg_date])."</font>"; 
	$date2="<font class=ver7>".date("H:i:s", $c_data[reg_date])."</font>"; 
?>

			<tr>
				<td>
			<table border=0 cellspacing=0 cellpadding=0 width=100% style="table-layout:fixed">
				<col width=></col><col width=60></col>
				<tr height=25>
					<td class=number_b><img src=<?=$dir?>/c_icon.gif align="absmiddle"> Commented by <?=$c_face_image?><?=$comment_name?></b>&nbsp;at <?=$date?>&nbsp;<?=$date2?>&nbsp;<?=$a_del?><img src=<?=$dir?>/c_delete.gif align="middle"></a></td>
					<td align=right><span class="vstarn"><?=$lvt_point?></span><span class="ip"> / 10.0</span></td>
				</tr>
				<tr style='padding:2 0 2 0'>
					<td colspan="2">

				<table border=0 cellspacing=1 cellpadding=0 bgcolor="#dddddd" width=100%>
					<tr>
						<td>

					<table border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff" width=100%>
						<tr>
							<td style='word-break:break-all;padding:2 4 2 4;line-height:160%;'><a class="more" onclick="this.innerHTML=(this.nextSibling.style.display=='none')?'':'';this.nextSibling.style.display=(this.nextSibling.style.display=='none')?'block':'none';" href="javascript:void(0);" onfocus='blur()'><b>����!</b> �� �ڸ�Ʈ�� �����Ϸ��� ���ԵǾ� ���� �� �ֽ��ϴ�. ������ ���÷��� Ŭ���ϼ���.</a><div style="DISPLAY: none"><?=str_replace("\n","<br>",$cmt_memo)?></div></td>
						</tr>
						<tr>
							<td align=right class='ip' style='padding:2 4 2 0'><? 
if($is_admin) { echo"IP ".$c_data[ip]."";} 
else { $ip_cut = substr($c_data[ip], 0, strrpos($c_data[ip], ".")+1); 
echo"IP ".$ip_cut."XXX";} 
?></td>
						</tr>
					</table></td>
					</tr>
				</table></td>
				</tr>
			</table></td>
			</tr>
			<tr height=10>
				<td></td>
			</tr>
<?
if(eregi(":\/\/",$dir)||eregi("\.\.",$dir)) $dir=".";
include "$dir/value.php3";
?>

<?
	// �� �ۼ��� �޽���
	if ($mode=="write") {
		$sitelink1="http://";
	}

	// ���ڼ� �����ϱ�
function text_cut($str, $len)
{
         if(strlen($str) > $len)
         {
                  if(ord($str[$len - 1]) <= 127) $pos = $len;
                  else
                  {
                           for($pos = $len - 1; $pos >= 0; $pos--)
                                    if(ord($str[$pos]) > 127) $h++;
                                    else break;

                           if($h%2==0) $pos += $h + 1;
                           else $pos += $h;
                  }

                  $str = substr($str, 0, $pos);
                        $str .="...";
         }

         return $str;
}

?>
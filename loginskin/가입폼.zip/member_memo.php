<?
// ���̺귯�� �Լ� ���� ��ũ���
	include "lib.php";

// DB ����
	if(!$connect) $connect=dbConn();

// ������� ���ϱ�
	$member=member_info();

	if(!$member[no]) Error("�α��ε� ȸ������ ����Ҽ� �ֽ��ϴ�","window.close");

// �׷쵥��Ÿ �о����;;
	$group_data=mysql_fetch_array(mysql_query("select * from $group_table where no='$member[group_no]'"));

// ������ �Խ��ϴ�;; �˶� ���ֱ�
	mysql_query("update $member_table set new_memo='0' where no='$member[no]'");

// ���� ���� �� ����;;
	mysql_query("delete from $get_memo_table where member_no='$member[no]' and (".time()." - reg_date) >= ".$_zbDefaultSetup[memo_limit_time]) or error(mysql_error());

// ���õ� �޸� ����;;;
	if($exec=="del_all") {
		for($i=0;$i<count($del);$i++) {
			mysql_query("delete from $get_memo_table where no='$del[$i]' and member_no='$member[no]'");
		}
		mysql_close($connect);
		movepage("$PHP_SELF?page=$page");
	}

// �޸����
	if($exec=="del") {
		mysql_query("delete from $get_memo_table where no='$no' and member_no='$member[no]'");
		mysql_close($connect);
		movepage("$PHP_SELF?page=$page");
	}

// ���õ� �޸� ������ ����Ÿ �̾ƿ���;;
	if($no) {
		$now_data=mysql_fetch_array(mysql_query("select * from $get_memo_table where no='$no' and member_no='$member[no]'"));
		if($now_data[readed]==1) {
			mysql_query("update $get_memo_table set readed='0' where no='$no' and member_no='$member[no]'");
			$check=mysql_fetch_array(mysql_query("select count(*) from $get_memo_table where readed='1' and member_no='$member[no]'")); 
			mysql_query("update $send_memo_table set readed='0' where reg_date='$now_data[reg_date]' and member_to='$member[no]'");
			if(!$check[0]) mysql_query("update $member_table set new_memo='0' where no='$member[no]'");
		}
	}

// ���� ���� ������ ���� ���ϱ�
	$temp1=mysql_fetch_array(mysql_query("select count(*) from $get_memo_table where readed='1' and member_no='$member[no]'"));

	$new_total=$temp1[0];

// ��ü ������ ����
	$temp2=mysql_fetch_array(mysql_query("select count(*) from $get_memo_table  where member_no='$member[no]'"));

	$total=$temp2[0];

// ������ ���
	if(!$page) $page=1;
	$page_num=13;
	$start_num=($page-1)*$page_num; // ������ ���� ���� ��½� ù��°�� �� ���� ��ȣ ����

	$total_page=(int)(($total-1)/$page_num)+1; // ��ü ������ ����

	if($page>$total_page) $page=$total_page; // �������� ��ü ���������� ũ�� ������ ��ȣ �ٲ�

// ����Ÿ �̾ƿ��� �κ�... 
	$que="select a.no as no, a.subject as subject, a.reg_date as reg_date, a.readed as readed, b.name as name, b.user_id as user_id, a.member_from as member_from from $get_memo_table a ,$member_table b where a.member_no='$member[no]' and a.member_from=b.no  order by a.no desc limit $start_num,$page_num";
	$result=mysql_query($que) or Error(mysql_error());

// MySQL �ݱ� 
	if($connect) mysql_close($connect);
	$query_time=getmicrotime();

// ������ ���  $print_page ��� ������ ���� 
	$print_page="";
	$show_page_num=10;
	$start_page=(int)(($page-1)/$show_page_num)*$show_page_num;
	$i=1;

	if($page>$show_page_num) {
		$prev_page=$start_page;
		$print_page="<a href=$PHP_SELF?id=$id&page=$prev_page&select_arrange=$select_arrange&desc=$desc&category=$category&sn=$sn&ss=$ss&sc=$sc&keyword=$keyword&page_num=$page_num>[Prev]</a> ";
		$print_page.="<a href=$PHP_SELF?id=$id&page=1&select_arrange=$select_arrange&desc=$desc&category=$category&sn=$sn&ss=$ss&sc=$sc&keyword=$keyword&page_num=$page_num>[1]</a>..";
	}

	while($i+$start_page<=$total_page&&$i<=$show_page_num) {
		$move_page=$i+$start_page;
		if($page==$move_page) $print_page.=" <b>$move_page</b> ";
		else $print_page.="<a href=$PHP_SELF?id=$id&page=$move_page&select_arrange=$select_arrange&desc=$desc&category=$category&sn=$sn&ss=$ss&sc=$sc&keyword=$keyword&page_num=$page_num>[$move_page]</a>";
		$i++;
	}

	if($total_page>$move_page) {
		$next_page=$move_page+1;
		$print_page.="..<a href=$PHP_SELF?id=$id&page=$total_page&select_arrange=$select_arrange&desc=$desc&category=$category&sn=$sn&ss=$ss&sc=$sc&keyword=$keyword&page_num=$page_num>[$total_page]</a>";
		$print_page.=" <a href=$PHP_SELF?id=$id&page=$next_page&select_arrange=$select_arrange&desc=$desc&category=$category&sn=$sn&ss=$ss&sc=$sc&keyword=$keyword&page_num=$page_num>[Next]</a>";
	}
   
	head("bgcolor=white");
?>

<script>
  function reverse() {
   var i, chked=0;
   for(i=0;i<document.list.length;i++)
   {
    if(document.list[i].type=='checkbox')
    {
     if(document.list[i].checked) { document.list[i].checked=false; }
     else { document.list[i].checked=true; }
    }
   }
  }
</script>

<style type="text/css">
BODY { scrollbar-3dlight-color:#dddddd;
scrollbar-arrow-color:#99CC66;
scrollbar-base-color:#FFFFFF;
scrollbar-darkshadow-color:#FFFFFF;
scrollbar-face-color:#FFFFFF;
scrollbar-highlight-color:#FFFFFF;
scrollbar-shadow-color:#FFFFFF}
A:link    {color:000000;text-decoration:none;}
A:visited {color:000000;text-decoration:none;}
A:active  {color:000000;text-decoration:none;}
A:hover  {color:409928;text-decoration:none;}

td,table {font-family:verdana;font-size:8pt;color:000000;line-height:170%;}
.han {font-family:����;font-size:8pt;color:000000;}
.en {font-family:tahoma;font-size:7pt;color:000000;}
</style>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      <img src="images/t.gif" width="10" height="2"><br>
      <img src="joinimg/memo_topright.gif"></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td class=han height=32>&nbsp;&nbsp;&nbsp;<a href=member_memo.php><img src="joinimg/alw.gif" border=0>����������</a> <a href=member_memo2.php><img src="joinimg/alw.gif" border=0>����������</a> <a href=member_memo3.php><img src="joinimg/alw.gif" border=0>��������Ʈ</a></a></td>
    <td align=right class=han><img src="images/t.gif" width="10" height="10"><font color="#666666">��ü :
      <b><?=$total?></b> , �� ���� : <b><?=$new_total?></b></font>&nbsp;&nbsp;&nbsp;&nbsp;</td>
  </tr>
</table>

<!-- ���õ� �޸� ������;; -->
<?
	if($now_data[no]) {

		$temp_name = get_private_icon($now_data[member_from], "2");
		if($temp_name) $now_data[name]="<img src='$temp_name' border=0 align=absmiddle>";
		$temp_name = get_private_icon($now_data[member_from], "1");
		if($temp_name) $now_data[name]="<img src='$temp_name' border=0 align=absmiddle>&nbsp;".$now_data[name];
?>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="15"></td>
    <td></td>
    <td width="15"></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="17"><img src="images/t.gif" width="17" height="10"></td>
    <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="3">
        <tr> 
          <td width="50" align="right" class=han>������ </td>
          <td><img src="images/t.gif" width="10" height="3"><br>
            <a href=javascript:void(window.open('view_info.php?member_no=<?=$now_data[member_from]?>','view_info','width=400,height=500,toolbar=no,scrollbars=yes'))><?=stripslashes($now_data[name])?></a> <font style=font-size:8pt;>(<b>ID</b> : <?=$now_data['user_id']?>)</td>
        </tr>
        <tr> 
          <td colspan="2" bgcolor="#E5E5E5" align="center" style=padding:0px;><img src="images/t.gif" width="10" height="1"></td>
        </tr>
        <tr> 
          <td width="50" align="right" class=han>���� </td>
          <td><img src="images/t.gif" width="10" height="3"><br>
            <?=stripslashes(del_html($now_data[subject]))?></td>
        </tr>
        <tr> 
          <td colspan="2" bgcolor="#E5E5E5" align="center" style=padding:0px;><img src="images/t.gif" width="10" height="1"></td>
        </tr>
        <tr> 
          <td width="50" align="right" class=han>��¥ </td>
          <td class=en><img src="images/t.gif" width="10" height="3"><br>
            <?=date("Y/m/d/ H:i",$now_data[reg_date])?></td>
        </tr>
        <tr> 
          <td colspan="2" bgcolor="#E5E5E5" align="center" style=padding:0px;><img src="images/t.gif" width="10" height="1"></td>
        </tr>
        <tr> 
          <td align="right" valign="top">���� </td>
          <td style='word-break:break-all;'><img src="images/t.gif" width="10" height="3"><br>
            <?=autolink(nl2br(stripslashes(del_html($now_data[memo]))))?><br>
            <br>
          </td>
        </tr>
        <tr>
          <td align="right" valign="top">&nbsp;</td>
          <td class=en><a href=javascript:void(window.open('view_info.php?member_no=<?=$now_data[member_from]?>','view_info','width=400,height=500,toolbar=no,scrollbars=yes'))>reply </a> <a href=<?=$PHP_SELF?>?exec=del&no=<?=$no?>&page=<?=$page?> onclick="return confirm('�����Ͻðڽ��ϱ�?')">delete </a> <a href=<?=$PHP_SELF?>>list</a> </td>
        </tr>
      </table>
    </td>
    <td width="17"><img src="images/t.gif" width="17" height="10"></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="15"></td>
    <td></td>
    <td width="15"></td>
  </tr>
</table>

<?
	}
?>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="15" height="1" bgcolor="#e3e3e3"></td>
    <td></td>
    <td width="15" height="1" bgcolor="#e3e3e3"></td>
  </tr>
</table>
<table border=0 width=100% cellpadding=0 cellspacing=0>
<tr>
<form method=post name=list action=<?=$PHP_SELF?> onsubmit="return confirm('�����Ͻðڽ��ϱ�?')">
<input type=hidden name=exec value=del_all>
<input type=hidden name=page value=<?=$page?>>
<td>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="17"><img src="images/t.gif" width="17" height="10"></td>
    <td>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="20" align="center"><a href=javascript:reverse()>��</a></td>
          <td width="20" align="center">&nbsp;</td>
          <td class=han height="35">����</td>
          <td width="100" height="35" align="center" class=han>������</td>
          <td width="50" height="35" align="center" class=han>��¥</td>
        </tr>
<?
	// ���
	$loop_number=$total-($page-1)*$page_num;
	while($data=mysql_fetch_array($result)) {
		$data[name]=stripslashes($data[name]);

		$temp_name = get_private_icon($data[member_from], "2");
		if($temp_name) $data[name]="<img src='$temp_name' border=0 align=absmiddle>";
		$temp_name = get_private_icon($data[member_from], "1");
		if($temp_name) $data[name]="<img src='$temp_name' border=0 align=absmiddle>&nbsp;".$data[name];
		
		$data[subject]=stripslashes(del_html($data[subject]));
		$reg_date=date("Y/m/d H:i",$data[reg_date]);
		if($data[readed]==0) $readed="<img src=images/memo_readed.gif>"; else $readed="<img src=images/memo_unread.gif>"
?>
        <tr> 
          <td colspan="5" bgcolor="#E5E5E5" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
        <tr onMouseOver=this.style.backgroundColor="#FFF5F5" onMouseOut=this.style.backgroundColor=""> 
          <td width="20" align="center" height="23"> 
            <input type=checkbox name=del[] value=<?=$data[no]?>>
          </td>
          <td width="20" align="center"><?=$readed?></td>
          <td height="35" style='word-break:break-all;' style=cursor:hand; onclick=location.href="<?="$PHP_SELF?exec=view&no=$data[no]&page=$page"?>"><img src="images/t.gif" width="10" height="3"><br>
            <a href=<?="$PHP_SELF?exec=view&no=$data[no]&page=$page"?>><?=$data[subject]?></a></td>
          <td width="100" height="35" align="center"><font class=han><img src="images/t.gif" width="10" height="3"><br>
            <a href=javascript:void(window.open('view_info.php?member_no=<?=$data[member_from]?>','view_info','width=400,height=510,toolbar=no,scrollbars=yes'))><?=$data[name]?></a></font><font style=font-size:7pt;color:8bbb73> <?=$data['user_id']?></td>
          <td width="50" height="35" align="center"><font style=font-family:Tahoma;font-size:7pt;><span title='<?=$reg_date?>'><? echo"".date("y/m/d",$data[reg_date])."" ?></span></font></td>
        </tr>
<?
 		$loop_number--;
	}
?>
      </table>
    </td>
    <td width="17"><img src="images/t.gif" width="17" height="10"></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="15" height="1" bgcolor="#e3e3e3"></td>
    <td></td>
    <td width="15" height="1" bgcolor="#e3e3e3"></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td>&nbsp;&nbsp;&nbsp;<font style=font-family:Tahoma;font-size:7pt;color:#cc0000><?=$print_page?></font></td>
    <td align="right"><input type=image src="joinimg/memo_delete.gif" border="0"> 
      <a href=JavaScript:window.close()><img src="joinimg/memo_close.gif" border="0"></a> </td>
  </tr>
</table></td>
</form>
</tr>
</table>
<script>
<?
	foot();
?>

<?
// ���̺귯�� �Լ� ���� ��ũ���
	include "lib.php";

// DB ����
	if(!$connect) $connect=dbConn();

// �۾����� ������ ������;;
	$data=mysql_fetch_array(mysql_query("select * from $member_table where no='$member_no'"));
	$data[name] = stripslashes($data[name]);
	$data[job] = stripslashes($data[job]);
	$data[email] = stripslashes($data[email]);
	$data[homepage] = stripslashes($data[homepage]);
	$data[birth] = stripslashes($data[birth]);
	$data[hobby] = stripslashes($data[hobby]);
	$data[icq] = stripslashes($data[icq]);
	$data[msn] = stripslashes($data[msn]);
	$data[home_address] = stripslashes($data[home_address]);
	$data[home_tel] = stripslashes($data[home_tel]);
	$data[office_address] = stripslashes($data[office_address]);
	$data[office_tel] = stripslashes($data[office_tel]);
	$data[handphone] = stripslashes($data[handphone]);
	$data[comment] = stripslashes($data[comment]);

	$temp_name = get_private_icon($data[no], "2");
	if($temp_name) $i_name="<img src='$temp_name' border=0 align=absmiddle>";
	$temp_name = get_private_icon($data[no], "1");
	if($temp_name) $i_name="<img src='$temp_name' border=0 align=absmiddle>&nbsp;".$i_name;
	$i_name="&nbsp;".$i_name."&nbsp;";

// $data �� ������, �� Ż���� ȸ���ΰ�� ǥ��
	if(!$data[no]) Error("Ż���� ȸ���Դϴ�", "window.close");

// ������� ���ϱ�
	$member=member_info();

// �׷쵥��Ÿ �о����;;
	$group_data=mysql_fetch_array(mysql_query("select * from $group_table where no='$data[group_no]'"));

	mysql_close($connect);

	head("bgcolor=white","script_memo.php");
?>

<?
if($data[no]&&($data[openinfo]||$member[is_admin]==1)) {
?>


<style type="text/css">
BODY { scrollbar-3dlight-color:#dddddd;
scrollbar-arrow-color:#99CC66;
scrollbar-base-color:#FFFFFF;
scrollbar-darkshadow-color:#FFFFFF;
scrollbar-face-color:#FFFFFF;
scrollbar-highlight-color:#FFFFFF;
scrollbar-shadow-color:#FFFFFF}


A:link    {color:000000;text-decoration:none;}
A:visited {color:000000;text-decoration:none;}
A:active  {color:000000;text-decoration:none;}
A:hover  {color:409928;text-decoration:none;}


td,table {font-family:verdana;font-size:8pt;color:000000;line-height:170%;}
.han {font-family:����;font-size:8pt;color:000000;}
.en {font-family:tahoma;font-size:7pt;color:000000;}
</style>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
<img src="joinimg/info.gif">
  </tr>
</table>
<?if($member[no]) { ?>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
 <td>&nbsp;&nbsp;&nbsp;<a href=view_info.php?member_no=<?=$member_no?>><img src=joinimg/smail.gif border=0></a></td>
  </tr>
</table>
<? }?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="15" height="1" bgcolor="#e3e3e3">
    <td></td>
    <td width="15" height="1" bgcolor="#e3e3e3">
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="17"><img src="images/t.gif" width="17" height="10"></td>
    <td>

<table border=0 cellspacing=0 cellpadding=0 width=100%>

<? if($data[open_picture]&&$data[picture]) { ?>
  <tr><td align=right valign=top class=han><img src=images/t.gif height=1><br>����&nbsp;&nbsp;</td><td align=left>&nbsp;<img src="<?=$data[picture]?>" border=0></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr> 
<? } ?>


  <tr>
     <td width=25%  height="23" align=right class=han>���̵�&nbsp;&nbsp;</td>
     <td align=left><img src="images/t.gif" width="10" height="3"><br><b><?=del_html($data[user_id])?></b></td>
  </tr>        
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
  <tr>
     <td align=right height="23" class=han>����&nbsp;&nbsp;</td>
     <td align=left class=en><img src="images/t.gif" width="10" height="3"><br><? if($data[is_admin]==1) echo "Super Administrator "; elseif($data[is_admin]==2) echo"Group Administrator "; else echo "Normal Member "; ?> (<?=$data[level]?>)
     </td>
  </tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
  <tr>
     <td align=right height="23" class=han>�̸�&nbsp;&nbsp;</td>
     <td align=left><img src="images/t.gif" width="10" height="3"><br><?=del_html($data[name])?> <?=$i_name?></td>
  </tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>

<? if($data[open_birth]&&$data[birth]) { ?>
  <tr><td align=right  height="23" class=han>����&nbsp;&nbsp;</td><td align=left><img src="images/t.gif" width="10" height="3"><br><?=date("Y�� m�� d��",$data[birth])?></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
<? } ?>

<? if($data[open_homepage]&&$data[homepage]) { ?>
  <tr><td align=right height="23" class=han>Ȩ������&nbsp;&nbsp;</td><td align=left class=en><img src="images/t.gif" width="10" height="3"><br><a href=<?=$data[homepage]?> target=_blank><?=$data[homepage]?></a></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
<? } ?>

<? if($data[open_icq]&&$data[icq]) {?>
  <tr><td align=right height="23" class=han>ICQ&nbsp;&nbsp;</td><td align=left><img src="images/t.gif" width="10" height="3"><br><?=$data[icq]?></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
<? } ?>

<? if($data[open_aol]&&$data[aol]) {?>
  <tr><td align=righ height="23" class=han>AIM&nbsp;&nbsp;</td><td align=left><img src="images/t.gif" width="10" height="3"><br><?=$data[aol]?></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
<? } ?>

<? if($data[open_msn]&&$data[msn]) {?>
  <tr><td align=right height="23" class=han>MSN&nbsp;&nbsp;</td><td align=left><img src="images/t.gif" width="10" height="3"><br><?=$data[msn]?></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
<? } ?>

<? if($data[open_hobby]&&$data[hobby]) {?>
  <tr><td align=right height="23" class=han>���&nbsp;&nbsp;</td><td align=left><img src="images/t.gif" width="10" height="3"><br><?=$data[hobby]?></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
<? } ?>

<? if($data[job]&&$data[open_job]) {?>
  <tr><td align=right height="23" class=han>����&nbsp;&nbsp;</td><td align=left><img src="images/t.gif" width="10" height="3"><br><?=$data[job]?></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
<? } ?>

<? if($data[home_address]||$data[home_tel]){ ?>
  <tr><td align=right height="23" class=han>����ȭ&nbsp;&nbsp;</td><td><?=$data[home_tel]?></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
<? } ?>

<? if($data[home_address]&&$data[open_home_address]) {?>
  <tr><td align=right valign=top height="23" class=han><img src=images/t.gif height=1><br>���ּ�&nbsp;&nbsp;</td><td align=left><img src="images/t.gif" width="10" height="3"><br><?=$data[home_address]?></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
<? } ?>


<? if($data[office_address]||$data[office_tel]){ ?>
  <tr height=23 class=han><td class=han align=right >ȸ���ȣ&nbsp;&nbsp;</td><td><?=$data[office_tel]?></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
<? } ?>

<? if($data[open_office_address]&&$data[office_address]) {?>
  <tr><td align=right valign=top  height="23" class=han>ȸ���ּ�&nbsp;&nbsp;</td><td align=left><img src="images/t.gif" width="10" height="3"><br><?=$data[office_address]?></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
<? } ?>



<? if($data[open_handphone]&&$data[handphone]) {?>
  <tr><td align=right height="23" class=han>�޴���&nbsp;&nbsp;</td><td align=left><img src="images/t.gif" width="10" height="3"><br><?=$data[handphone]?></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
<? } ?>

<? if($data[open_comment]&&$data[comment]) {?>
  <tr><td align=right height="23" class=han>�ڱ�Ұ�&nbsp;&nbsp;</td><td align=left><img src="images/t.gif" width="10" height="3"><br><?=nl2br(del_html($data[comment]))?></td></tr>
        <tr>
          <td colspan="5" bgcolor="#e3e3e3" align="center"><img src="images/t.gif" width="10" height="1"></td>
        </tr>
<? } ?>

<tr>
   <td align=right height="23" class=han>����Ʈ&nbsp;&nbsp;</td>
   <td align=left height="23" ><img src="images/t.gif" width="10" height="3"><br><?=($data[point1]*10+$data[point2])?> �� ( �ۼ��ۼ� : <?=$data[point1]?>, �ڸ�Ʈ : <?=$data[point2]?> )</td>
</tr>
</table>
    </td>
    <td width="17"><img src="images/t.gif" width="17" height="10"></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="15" height="1" bgcolor="#e3e3e3"></td>
    <td></td>
    <td width="15" height="1" bgcolor="#e3e3e3"></td>
  </tr>
</table>
<table border=0 width=98%>
<tr><td align=right><a href=JavaScript:window.close()><img src="joinimg/no.gif" border="0"></a></tD></tr>
</table>

<?
 } else Error("������ �����Ǿ� ���� �ʽ��ϴ�", "window.close");
?>

<?
	foot();
?>

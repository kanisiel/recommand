<?
$m_subject = explode("|",$subject);
$subject1   = $m_subject[0];
$subject2		= $m_subject[1];
$subject3  = $m_subject[2];
$subject4  = $m_subject[3];
$subject5  = $m_subject[4];
$subject6  = $m_subject[5];
$subject7  = $m_subject[6];
$subject8  = $m_subject[7];
$subject9  = $m_subject[8];
$subject10  = $m_subject[9];
$subject11  = $m_subject[10];
$subject12  = $m_subject[11];
$subject13  = $m_subject[12];
$subject14  = $m_subject[13];
$subject15  = $m_subject[14];
$subject16  = $m_subject[15];
$subject17  = $m_subject[16];
$subject18  = $m_subject[17];
$subject19  = $m_subject[18];
$subject20  = $m_subject[19];
?>

<SCRIPT LANGUAGE="JavaScript">
function toggle(el) { 
if (el.style.display == 'none'){ 
el.filters.blendTrans.Apply(); 
el.style.display = ''; 
el.filters.blendTrans.Play() 
} 
else { 
el.filters.blendTrans.Apply(); 
el.style.display = 'none'; 
el.filters.blendTrans.Play() 
} 
}

var goodjava;
function viewPic(img){
if(img=='') {
return;
}else {
goodjava= new Image();
goodjava.src=(img);
contImg(img);
}
}
function contImg(img){
if((goodjava.width!=0)&&(goodjava.height!=0)){
viewImg(img);
}
else{
funzione="contImg('"+img+"')";
intervallo=setTimeout(funzione,20);
}
}
function viewImg(img){
document.all["good_pre"].innerHTML="<font color=blue><img name=img width=145 height=180 src=#><br>W=" + goodjava.width + "px , H=" + goodjava.height + "px";
document.img.src = goodjava.src;
}

function bodyimgprint(imgurl,title){
if(imgurl.length < 10){return;}
imgwindo = window.open('', 'Winopen', 'scrollbars=1,resizable=1,width=300,height=300');
imgwindo.document.write('<html><title> ' +title+ ' �ƢƢƢƢƢƢƢƢƢƢƢƢƢƢƢƢ�</title><body topmargin=1 leftmargin=1 style=overflow:auto;border-width:0></body></html>');
imgwindo.document.body.innerHTML ='<div align=center><a href=javascript:window.close()><img src="'+ imgurl +'" border=0 alt=close  onload=if(this.height&&this.width){window.resizeTo(this.width+30,this.height+90);}></a><br><br><input type=button value="CLOSE" onclick=window.close() style=font-size:9pt;background-color:#f2f2f2;border-width:1;border-style:solid;></div>';
imgwindo.focus();
imgwindo.moveTo(300,100); 
}

function BlankUrl(subject11) {
var load
load = "http://www.aladdin.co.kr/Cover/" + subject11 + "_1.gif"
if (load != "") {
remote=window.open(load);
}
}

function BuyUrl(sitelink1) {
var buyload
buyload = sitelink1
if (buyload != "") {
remote=window.open(buyload);
}
}

window.onerror=function error_kill() {return true;} 

function view(what) {  
var imgwin = window.open("",'WIN','scrollbars=no,status=no,toolbar=no,resizable=1,location=no,menu=no,width=20,height=20');  
imgwin.focus();  
imgwin.document.open();  
imgwin.document.write("<html>");  
imgwin.document.write("<head>");  
imgwin.document.write("<title>ǥ������</title>");  

imgwin.document.write("<sc"+"ript>\n");  
imgwin.document.write("function resize() {\n");  
imgwin.document.write("pic = document.il;\n");  
//imgwin.document.write("alert(eval(pic).height);\n");  
imgwin.document.write("if (eval(pic).height) { var name = navigator.appName\n");  
imgwin.document.write("  if (name == 'ǥ������') { myHeight = eval(pic).height + 0; myWidth = eval(pic).width + 0;\n");  // 40 12
imgwin.document.write("  } else { myHeight = eval(pic).height + 60; myWidth = eval(pic).width; }\n");  // 9
imgwin.document.write("  clearTimeout();\n");  
imgwin.document.write("  var height = screen.height;\n");  
imgwin.document.write("  var width = screen.width;\n");  
imgwin.document.write("  var leftpos = width / 2 - myWidth / 2;\n");  
imgwin.document.write("  var toppos = height / 2 - myHeight / 2; \n");  
imgwin.document.write("  self.moveTo(leftpos, toppos);\n");  
imgwin.document.write("  self.resizeTo(myWidth, myHeight);\n");  
imgwin.document.write("}else setTimeOut(resize(), 100);}\n");  
imgwin.document.write("</sc"+"ript>");  

imgwin.document.write("</head>");  
imgwin.document.write('<body topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bgcolor="#FFFFFF">');  
imgwin.document.write('<table border=0 cellpadding=5 cellspacing=0 width=100%><tr><td><span style=font-size:9pt;><font color=#FF6600>��</font> <font color=blue>*CLICK TO CLOSE.</font></span></td></tr></table>');  
imgwin.document.write("<a href=# onclick=window.close() onfocus=this.blur()><img border=0 src="+what+" xwidth=100 xheight=9 name=il onload='resize();'></a>");  
imgwin.document.write("</body>");  
imgwin.document.close();  
}  
</script>


<table border=0 width=<?=$width?> cellspacing=1 cellpadding=5 bgcolor=cccccc>
<tr><td valign=top bgcolor=f7f7f7>
<table border=0 width=100% height=100% cellspacing=0 cellpadding=3 style=table-layout:fixed>
<form method=post name=write action=goodjava_book.php onsubmit="return check_submit();" enctype=multipart/form-data><input type=hidden name=page 
value=<?=$page?>><input type=hidden name=id value=<?=$id?>><input type=hidden name=no value=<?=$no?>><input type=hidden name=select_arrange 
value=<?=$select_arrange?>><input type=hidden name=desc value=<?=$desc?>><input type=hidden name=page_num value=<?=$page_num?>><input type=hidden 
name=keyword value="<?=$keyword?>"><input type=hidden name=category value="<?=$category?>"><input type=hidden name=sn value="<?=$sn?>"><input type=hidden 
name=ss value="<?=$ss?>"><input type=hidden name=sc value="<?=$sc?>"><input type=hidden name=mode value="<?=$mode?>">


<col width=80 align=right></col><col width=100% style='padding-left:5px;'></col>

<tr>
  <td colspan=2 align=left style='padding-left:5px;'><br><b>My Information</b><br>  
  <hr size="2" width="98%" noshade color="#999999"></td>
</tr>
<?=$hide_start?>
<tr>
  <td>password</td>
  <td><input type=password name=password <?=size(20)?> maxlength=20 class=b_input></td>
</tr>

<tr>
  <td> Name </td>
  <td><input type=text name=name value="<?=$name?>" <?=size(20)?> maxlength=20 class=b_input>
</tr>
<?=$hide_end?>

<tr>
  <td>Option</td>
  <td class=t7>
       <?=$hide_html_start?> <input type=checkbox name=use_html <?=$use_html?> value=1> HTML <?=$hide_html_end?>
       <input type=checkbox name=reply_mail <?=$reply_mail?> value=1> REPLY MAIL
       <?=$hide_secret_start?> <input type=checkbox name=is_secret <?=$secret?> value=1> SECRET <?=$hide_secret_end?>
  </td>
</tr>

<?=$hide_cart_start?>
<tr>
  <td>Category</td>
  <td class=t7><?=$category_kind?></td>
</tr>
<?=$hide_cart_end?>

<tr>
  <td>��õ��</td>
  <td class=t7>
       <input type=checkbox name=subject15 <?if($subject15=="1"){echo "checked";}?> value=1> <img src=<?=$dir?>/images/1.gif border=0>
       <input type=checkbox name=subject16 <?if($subject16=="1"){echo "checked";}?> value=1> <img src=<?=$dir?>/images/2.gif border=0>
       <input type=checkbox name=subject17 <?if($subject17=="1"){echo "checked";}?> value=1> <img src=<?=$dir?>/images/3.gif border=0>
  </td>
</tr>


<tr>
  <td colspan=2 align=left style='padding-left:5px;'><br><b>Book Information #1</b><br>  
  <hr size="2" width="98%" noshade color="#999999"></td>
</tr>

<tr>
  <td><b>����</b></td>
  <td><input type=text name=subject1 value="<?=$subject1?>" <?=size(60)?> maxlength=200 class=b_input></td>
</tr>
<tr>
  <td>������</td>
  <td><input type=text name=subject2 value="<?=$subject2?>" <?=size(60)?> maxlength=200 class=b_input></td>
</tr>

<tr>
  <td></td>
  <td>
  <table border=0 width=100% cellspacing=0 cellpadding=0>
  <col width=150 align=right></col><col width=100% style='padding-left:5px;'></col>
  <tr>
  	<td valign=top>
  			<table border=0 cellspacing=0 cellpadding=0>
  			  <tr>
  			  	 	<td bgcolor=#f7f7f7 valign=top>
 					 			<table border=0 width=150 height=199 cellspacing=1 cellpadding=0 bgcolor=#666666>
 					 			  <tr>
  								  	 	<td align=center bgcolor=#f7f7f7 background="<?=$dir?>/images/img_bg.gif">
  								  	 		<div id=good_pre></div>
  								  	 	</td>
								  </tr>	
							  </table>  			  	 	
  			  	 	
  			  	 	
  			  	 	
  			  	 	</td>
				  </tr>	
			  </table>
  	</td>
  	<td>
  			<table border=0 width=95% cellspacing=1 cellpadding=0 bgcolor=#666666>
  			<col width=60 align=right style='padding-right:5px;'></col><col style='padding-left:5px;' width= ></col>
<tr>
  <td bgcolor=#f7f7f7>��&nbsp;&nbsp;&nbsp;��</td>
  <td bgcolor=#f7f7f7><input type=text name=subject3 value="<?=$subject3?>" <?=size(30)?> maxlength=200 class=b_input></td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>��&nbsp;&nbsp;&nbsp;��</td>
  <td bgcolor=#f7f7f7><input type=text name=subject4 value="<?=$subject4?>" <?=size(30)?> maxlength=200 class=b_input>��</td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>�ǸŰ�</td>
  <td bgcolor=#f7f7f7><input type=text name=subject5 value="<?=$subject5?>" <?=size(30)?> maxlength=200 class=b_input>��</td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>������</td>
  <td bgcolor=#f7f7f7><input type=text name=subject6 value="<?=$subject6?>" <?=size(30)?> maxlength=200 class=b_input>%</td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>���ǻ�</td>
  <td bgcolor=#f7f7f7><input type=text name=subject7 value="<?=$subject7?>" <?=size(30)?> maxlength=200 class=b_input></td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>������</td>
  <td bgcolor=#f7f7f7><input type=text name=subject8 value="<?=$subject8?>" <?=size(30)?> maxlength=200 class=b_input>��</td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>ũ&nbsp;&nbsp;&nbsp;��</td>
  <td bgcolor=#f7f7f7><input type=text name=subject9 value="<?=$subject9?>" <?=size(30)?> maxlength=200 class=b_input></td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>������</td>
  <td bgcolor=#f7f7f7><input type=text name=subject10 value="<?=$subject10?>" <?=size(30)?> maxlength=200 class=b_input></td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>ISBN</td>
  <td bgcolor=#f7f7f7>
<input type="text" name="subject11" value="<?=$subject11?>" <?=size(13)?> maxlength="30" class=b_input> 
<input type="button" value="ISBN Image" onclick="BlankUrl(subject11.value)" class=submit></td>
</td>
</tr>
			  </table>  	
  	</td>
  </tr>	
  </table>
  </td>
</tr>

<?=$hide_pds_start?>
<tr>
  <td>��������</td>
  <td>
  <table border=0 width=95% cellspacing=0 cellpadding=0>
  <tr><td width=75%>
  <input type=file name=file1 class=b_input onFocus="viewPic(this.value);" style=width:99%><?=$file_name1?>
  </td>
  <td align=left>
<?
  if($data[file_name1])
  {
  ?>
  <span><a href="javascript:view('<?=$data[file_name1]?>')" onfocus="this.blur()"><img src=<?=$data[file_name1]?> width=45 height=52 border=0></a></span>
  <?
  }
  else
  {
  ?>
  <?
  }
  ?>  
  </td>
  </tr></table>
  
  </td>
</tr>
<tr>
  <td>Ȯ�����</td>
  <td>
  <table border=0 width=95% cellspacing=0 cellpadding=0>
  <tr><td width=75%>
  <input type=file name=file2 class=b_input onpropertychange="bodyimgprint(this.value,'Ȯ�����')" style=width:99%> <?=$file_name2?>
  </td>
  <td align=left>
<?
  if($data[file_name2])
  {
  ?>
  <span><a href="javascript:view('<?=$data[file_name2]?>')" onfocus="this.blur()"><img src=<?=$data[file_name2]?> width=45 height=52 border=0></a></span>
  <?
  }
  else
  {
  ?>
  <?
  }
  ?>  
  </td>
  </tr></table>

</td>
</tr>
<?=$hide_pds_end?>

<tr>
  <td colspan=2 align=left style='padding-left:5px;'><br><b>���Ÿ�ũ�� #1, #2 �߿��� �ϳ��� �Է��ϼ���.</b><br>  
  <hr size="2" width="98%" noshade color="#999999"></td>
</tr>

<?=$hide_sitelink1_start?>
<tr>
  <td>���Ÿ�ũ#1</td>
  <td><input type="text" name="sitelink1" value="<?=$sitelink1?>" <?=size(50)?> maxlength="200" class=b_input> 
  <input type="button" value="���Ÿ�ũ Ȯ��" onclick="BuyUrl(sitelink1.value)" class=submit></td>  
</tr>
<?=$hide_sitelink1_end?>

<tr>
  <td>���Ÿ�ũ#2</td>
  <td><textarea name="subject18" rows=5 class=b_textarea style=width:97%><?=$subject18?></textarea><br>
  		* #2�� html �ڵ带 �Է��ϴ� ���Դϴ�. �ɼ��� html�� �����Ͻ� �� 'Ȯ��'�� �����ϼ���.<br>
  		* ���Ž�û ��ư �̹��� �ּ� : &lt;img src=images/buynow.gif border=0&gt; <br>
  		* <a style='cursor:hand' onclick='toggle(help);'><b><u>���� [����/�ݱ�]</u></b></a>
<span id='help' style='display:none;width:100%;filter:blendTrans(Duration=0.5)'>
<table border=1 width=97% cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#e0e0e0"> 
	<tr>
	  <td>* ���Ÿ�ũ #2 �� ���޸����� ����Ʈ�� �ڵ带 �Է��ϴ� �κ��Դϴ�.<br>
	  * <a onmouseover="window.status='http://www.linkprice.com';return true" onmouseout="window.status=' ';return true" target="_blank" href="http://click.linkprice.com/click.php?m=linkprice&a=A100048344&l=0002&u_id="><u><b>Linkprice.com �� ������ �����帮�ڽ��ϴ�.</b></u></a><img src="http://track.linkprice.com/lpshow.php?m_id=linkprice&a_id=A100048344&p_id=0000&l_id=0002&l_cd1=1&l_cd2=0" width="1" height="1" border="0" nosave style="display:none">
	  </td>
	</tr>
	<tr>
	  <td>
	  	<table border=0 width=100% cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#e0e0e0">
	  		<tr>
				  <td width=300>
					  <a href="javascript:view('<?=$dir?>/images/linkprice_1.gif')" onfocus="this.blur()"><img src=<?=$dir?>/images/linkprice_1_s.gif border=0></a>
					  <a href="javascript:view('<?=$dir?>/images/linkprice_2.gif')" onfocus="this.blur()"><img src=<?=$dir?>/images/linkprice_2_s.gif border=0></a><br>
					  <a href="javascript:view('<?=$dir?>/images/linkprice_3.gif')" onfocus="this.blur()"><img src=<?=$dir?>/images/linkprice_3_s.gif border=0></a>
					  <a href="javascript:view('<?=$dir?>/images/linkprice_4.gif')" onfocus="this.blur()"><img src=<?=$dir?>/images/linkprice_4_s.gif border=0></a>	  	  	  
				  </td>
				  <td valign=middle>
				  	* ���Ÿ�ũ#2�� ���� ���Ÿ�ũ#1�� ������� ���ñ� �ٶ��ϴ�.<br>
				  	* ���Ÿ�ũ �̹����� bbs/images/ �� �־� �ֽñ� �ٶ��ϴ�.<br>
				  	* ���Ÿ�ũ �̹����� ���� �ּҸ� �״�� �Է��Ͻø� �˴ϴ�.

				  </td>				  
				</tr>	
			</table> 
	  </td>
	</tr>	
</table> 
</span>   		
  		</td>
</tr>






<tr>
  <td colspan=2 align=left style='padding-left:5px;'><br><b>Book Information #2</b><br>  
  <hr size="2" width="98%" noshade color="#999999"></td>
</tr>

<tr>
  <td>å�Ұ�</td>
  <td><textarea name="subject12" rows=5 class=b_textarea style=width:97%><?=$subject12?></textarea></td>
</tr>
<tr>
  <td>������ �Ұ�</td>
  <td><textarea name="subject13" rows=5 class=b_textarea style=width:97%><?=$subject13?></textarea></td>
</tr>
<tr>
  <td>åǥ����</td>
  <td><textarea name="subject14" rows=5 class=b_textarea style=width:97%><?=$subject14?></textarea></td>
</tr>


<tr>
  <td colspan=2 align=left style='padding-left:5px;'><br><b>Review</b><br>  
  <hr size="2" width="98%" noshade color="#999999"></td>
</tr>

<tr>
  <td><b>���ǻ� ����</b></td>
  <td><textarea name="sitelink2" rows=5 class=b_textarea style=width:97%><?=$sitelink2?></textarea></td>
</tr>

<?=$hide_sitelink2_start?>
<tr>
  <td><b>���ʺ���</b></td>
  <td><textarea name="memo" rows=5 class=b_textarea style=width:97%><?=$memo?></textarea></td>
</tr>
<?=$hide_sitelink2_end?>

<tr><td height=10 colspan=2></td></tr>
</table>
</td></tr>
</table>

<table border=0 width=<?=$width?> cellspacing=0 cellpadding=5>
<tr>
<td>&nbsp;</td>
<td align=right>
<input type=image src="<?=$dir?>/images/write_ok.gif" accesskey="s">
<img src="<?=$dir?>/images/back.gif" style="cursor:hand" onclick=history.back()>
</td>
</tr>
</table>
<br>

</table>
<? $c_name = str_replace("<input", "<input class=b_input",$c_name); ?>

<table border=0 cellspacing=1 cellpadding=0 class=line3 width=<?=$width?>>
   <tr>  
       <td bgcolor=white>	
            <table border=0 cellspacing=0 cellpadding=0 width=100%>		
                 <script>			function check_comment_submit(obj) {				if(obj.memo.value.length<10) {					alert("�ڸ�Ʈ�� 10�� �̻� �����ּ���");					obj.memo.focus();					return false;				}				return true;			}		</script>		
                 <form method=post name=write action=comment_ok.php onsubmit="return check_comment_submit(this)">
                 <input type=hidden name=page value=<?=$page?>>
                 <input type=hidden name=id value=<?=$id?>>
                 <input type=hidden name=no value=<?=$no?>>
                 <input type=hidden name=select_arrange value=<?=$select_arrange?>>
                 <input type=hidden name=desc value=<?=$desc?>>
                 <input type=hidden name=page_num value=<?=$page_num?>>
                 <input type=hidden name=keyword value="<?=$keyword?>">
                 <input type=hidden name=category value="<?=$category?>">
                 <input type=hidden name=sn value="<?=$sn?>">
                 <input type=hidden name=ss value="<?=$ss?>">
                 <input type=hidden name=sc value="<?=$sc?>">
                 <input type=hidden name=mode value="<?=$mode?>"> 

               <tr align=center valign=top>	  
                 <td nowrap><?=$c_name?><?=$hide_c_password_start?>
                 <br><img src=<?=$dir?>/t.gif border=0 height=10><br><font style=font-family:Verdana;font-size:8pt;letter-spacing:-1px;>
                 <font class=list_han>���̸�/�����</font>
                 <br><img src=<?=$dir?>/t.gif border=0 height=5><br><input type=password name=password <?=size(8)?> maxlength=20 class=b_input>
                 <?=$hide_c_password_end?></td>	  
                 
                 <td width=100%><textarea name=memo <?=size(40)?> rows=5 class=b_textarea style="width:98%;"></textarea></td>	  
                 <td height=70><input type=submit rows=5 <?if($browser){?> class=b_textarea <?}?> value='�Ұ� ���' accesskey="s" style=height:100%></td>	
               </tr>	

            </table>  
         </td>
  </tr>
</table>

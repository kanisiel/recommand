<div align=center>
<br><br><br>
<table border=0 width=300 cellspacing=1 cellpadding=5 bgcolor=cccccc>
<tr><td valign=top bgcolor=f7f7f7>
<table border=0 width=100% height=100% cellspacing=0 cellpadding=3 style=table-layout:fixed>
<tr>
<td colspan=2 height=1 bgcolor=#cdcdcd></td>
</tr>
<tr height=20 valign=bottom>
<td align=left><img src=images/t.gif width=15>ID</td>
<td align=left><img src=images/t.gif width=15>PASSWORD</td>
</tr>
<tr height=25>
<td height=40 align=center><input type=text name=user_id size=<?if($browser)echo"15";else echo"10";?> maxlength=20 class=input></td>
<td align=center><input type=password name=password size=<?if($browser)echo"15";else echo"10";?> maxlength=20 class=input > </td>
</tr>
<tr>
<td colspan=2 align=center valign=bottom>
<input type=image border=0 src=<?=$dir?>/images/ok.gif onfocus=blur()> 
<a href=# onclick=history.go(-1) onfocus=blur()><img src=<?=$dir?>/images/back.gif border=0></a></td>
</tr>

<tr>
<td colspan=2 height=1 bgcolor=#cdcdcd></td>
</tr>
</table>

</td></tr>
</table>

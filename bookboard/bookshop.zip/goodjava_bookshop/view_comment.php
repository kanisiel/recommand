<tr>
  <td><table height=3><tr><td></td></tr></table></td>
</tr>
<tr>
  <td style='padding-left:5px;' align=left>
  <table border=0 width=<?=$width?> cellspacing=0 cellpadding=0>
  <tr><td>
  <br><b><?=$comment_name?>���� �Ұ�</b><br>
  <hr size="2" width="<?=$width?>" noshade color="#999999">
  </td></tr></table>
  </td>
</tr>

<tr valign=top>
<td>

<table border=0 width=<?=$width?> cellspacing=1 cellpadding=5 bgcolor=cccccc>
<tr><td valign=top bgcolor=f7f7f7>
<table border=0 width=100% height=100% cellspacing=0 cellpadding=3 style=table-layout:fixed>
<tr>
<td style='padding:5px'><font class=siche_text_s><?=date("Y-m-d H:i:s",$c_data[reg_date])?></font></td>
<td align=right><?=$a_del?>Delete</a></td>
</tr>
<tr>
<td style='padding:5px'><?=nl2br($c_memo)?></td>
</tr>
<tr><td height=3></td></tr>
</table>
</td></tr>
</table>

</td>
</tr>

<tr>
  <td><table height=3><tr><td></td></tr></table></td>
</tr>

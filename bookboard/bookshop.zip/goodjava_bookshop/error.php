<br><br><br>
<div align=center>
<form>
<table border=0 width=300 cellspacing=1 cellpadding=5 bgcolor=cccccc>
<tr><td valign=top bgcolor=f7f7f7>
<table border=0 width=100% height=100% cellspacing=0 cellpadding=3 style=table-layout:fixed>
<tr>
<td colspan=2 height=1 bgcolor=#cdcdcd></td>
</tr>

<tr style=padding:5px;>
    <td align=center height=30>
      <br>
      <?echo $message;?><br><br>
</td>
</tr>
<tr>
<td colspan=2 height=1 bgcolor=#cdcdcd></td>
</tr>
<tr>
<td height=50 align=right colspan=2 valign=bottom>

<?
  if(!$url)
  {
?>

  <p align=center><img src=images/t.gif height=3><br><img onclick=history.back() border=0 align=absmiddle src=<?=$dir?>/images/back.gif onfocus=blur() style="cursor:hand">

<?
  }
  else
  {
?>

  <div align=center><input type=button value='   Move   ' onclick=location.href="<?echo $url;?>" class=b_input onfocus=blur()>

<?
  }
?>
   <br><br>
    </td>
</tr>
</form>
<td colspan=2 height=1 bgcolor=#cdcdcd></td>
</tr>
</table>

</td></tr>
</table>
</div>
<br><br>

<html>
<head>
	<title>View Image</title>
	<meta http-equiv=Content-Type content=text/html; charset=EUC-KR>
<body topmargin='0'  leftmargin='0' marginwidth='0' marginheight='0'>
<A href=# onclick=window.close()><img src=../../<?=$file?> border=0></a>
</body>
</head>
</html>

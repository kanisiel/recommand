<tr><td height=10></td></tr>
</table>
</td></tr>
</table>

<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
</form>
<tr>
	<td height=1 bgcolor=#CDCDCD></td>
</tr>
</table>
<table border=0 cellpadding=0 cellspacing=0 width=<?=$width?>>
<tr><td><img src=<?=$dir?>/t.gif height=5 width=1 border=0></td></tr>
<tr>
	<td><?=$a_prev_page?>[next]</a></font> <?=$print_page?> <font class=siche_text_s><?=$a_next_page?>[prev]</font></a></td>
	<td width=200 align=right valign=bottom>
	<?=$a_list?><img src=<?=$dir?>/images/list.gif border=0></a> <?=$a_write?><img src=<?=$dir?>/images/write.gif border=0></a>
	</td>
</tr>
</table>





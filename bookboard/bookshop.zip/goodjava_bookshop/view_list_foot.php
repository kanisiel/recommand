</table>
<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
<tr>
<td height=1 bgcolor=#CDCDCD></td>
</tr>
</table>
<table border=0 cellpadding=0 cellspacing=0 width=<?=$width?>>
<tr><td><img src=<?=$dir?>/t.gif height=5 width=1 border=0></td></tr>
<tr>
<td width=60><?=$a_list?><img src=<?=$dir?>/i_list.gif border=0></a> </td>
<td align=center>&nbsp;</td>
<td width=130 align=right><?=$a_delete_all?><img src=<?=$dir?>/i_admin.gif border=0></a> <?=$a_write?><img src=<?=$dir?>/i_write.gif border=0></a></td>
</tr>
</table>
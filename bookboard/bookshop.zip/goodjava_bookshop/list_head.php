<table border=0 width=<?=$width?> cellspacing=1 cellpadding=5 bgcolor=cccccc>
<form method=post name=list action=list_all.php><input type=hidden name=page value=<?=$page?>><input type=hidden name=id value=<?=$id?>><input type=hidden name=select_arrange value=<?=$select_arrange?>><input type=hidden name=desc value=<?=$desc?>><input type=hidden name=page_num value=<?=$page_num?>><input type=hidden name=selected><input type=hidden name=exec><input type=hidden name=keyword value="<?=$keyword?>"><input type=hidden name=sn value="<?=$sn?>"><input type=hidden name=ss value="<?=$ss?>"><input type=hidden name=sc value="<?=$sc?>">
<tr><td valign=top bgcolor=f7f7f7>
<table border=0 width=100% height=100% cellspacing=0 cellpadding=3 style=table-layout:fixed>
<tr>
<td>
<table border=0 cellspacing=0 cellpadding=0 width=100%>
<tr>
<td valign=top>
<?=$a_login?>Login</a>
<?=$a_member_join?>Join</a>
<?=$a_member_modify?>Info</a>
<?=$a_member_memo?>Memo</a>
<?=$a_logout?>Logout</a>
<?=$a_setup?>Setup</a>
</td>


<td align=right>
<?=$hide_category_start?><?=$a_category?> <a href="./zboard.php?id=<?=$id?>"><img src=<?=$dir?>/images/list_board_search.gif alt=��ü����Ʈ ���� border=0></a><?=$hide_category_end?><a style='cursor:hand' onclick='toggle(good);'><img src=<?=$dir?>/images/search.gif border=0 alt="�˻�â ����/�ݱ�"></a>&nbsp;&nbsp;
</form>
<span id='good' style='display:none;width:100%;filter:blendTrans(Duration=0.5)'>
<table border=0 align=right cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#e0e0e0"> 
	<form method=post name=search action=<?=$PHP_SELF?>><input type=hidden name=page value=<?=$page?>><input type=hidden name=id value=<?=$id?>><input type=hidden name=select_arrange value=<?=$select_arrange?>><input type=hidden name=desc value=<?=$desc?>><input type=hidden name=page_num value=<?=$page_num?>><input type=hidden name=selected><input type=hidden name=exec><input type=hidden name=sn value="<?=$sn?>"><input type=hidden name=ss value="<?=$ss?>"><input type=hidden name=sc value="<?=$sc?>"><input type=hidden name=category value="<?=$category?>">
	<tr>
	<td width=100><input type=text name=keyword value="<?=$keyword?>" class=b_input></td>
	<td width=45 align=left valign=absmiddle><input type=image src=<?=$dir?>/images/search.gif border=0 onfocus=blur()>&nbsp;&nbsp;</td>
	</tr>
	</form>
</table> 
</span> 
</td>
</tr>
</table>

</td>
</tr>

<tr>
	<td height=1 bgcolor=#CDCDCD></td>
</tr>




<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
<form method=post name=list action=list_all.php><input type=hidden name=page value=<?=$page?>><input type=hidden name=id value=<?=$id?>><input type=hidden name=select_arrange value=<?=$select_arrange?>><input type=hidden name=desc value=<?=$desc?>><input type=hidden name=page_num value=<?=$page_num?>><input type=hidden name=selected><input type=hidden name=exec><input type=hidden name=keyword value="<?=$keyword?>"><input type=hidden name=sn value="<?=$sn?>"><input type=hidden name=ss value="<?=$ss?>"><input type=hidden name=sc value="<?=$sc?>">
<?=$hide_cart_start?><col width=27></col><?=$hide_cart_end?>
<col width=35></col>
<?=$hide_category_start?><col width=75></col><?=$hide_category_end?>
<col width=></col>
<col width=100></col>
<col width=60></col>
<col width=50></col>
<tr>
<?=$hide_cart_start?><td background=<?=$dir?>/h_bg.gif><img src=<?=$dir?>/h_bg.gif></td><?=$hide_cart_end?>
<td background=<?=$dir?>/h_bg.gif><img src=<?=$dir?>/h_bg.gif></td>
<?=$hide_category_start?><td background=<?=$dir?>/h_bg.gif></td><?=$hide_category_end?>
<td background=<?=$dir?>/h_bg.gif></td>
<td background=<?=$dir?>/h_bg.gif></td>
<td background=<?=$dir?>/h_bg.gif></td>
<td background=<?=$dir?>/h_bg.gif></td>
</tr>
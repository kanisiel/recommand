<tr valign=bottom align=center onMouseOver=this.style.backgroundColor='#F7F7F7' onMouseOut=this.style.backgroundColor=''>
<?=$hide_cart_start?><td><input type=checkbox name=cart value="<?=$data[no]?>"></td><?=$hide_cart_end?>
<td height=20><?=$number?></td>
<?=$hide_category_start?><td align=left>[<?=$category_name?>]</td><?=$hide_category_end?>
<td align=left>&nbsp;<?=$insert?><?=$icon?> <?=$subject?> <font class=siche_text_s><?=$comment_num?></font></td>
<td nowrap><?=$face_image?>&nbsp;<?=$name?></td>
<td nowrap><?=$reg_date?></td>
<td nowrap><?=$hit?></td>
</tr>
<tr>
<td colspan=8></td>
</tr>
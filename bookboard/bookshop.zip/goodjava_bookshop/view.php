<?
$m_subject = explode("|",$subject);
$subject1   = $m_subject[0];
$subject2		= $m_subject[1];
$subject3  = $m_subject[2];
$subject4  = $m_subject[3];
$subject5  = $m_subject[4];
$subject6  = $m_subject[5];
$subject7  = $m_subject[6];
$subject8  = $m_subject[7];
$subject9  = $m_subject[8];
$subject10  = $m_subject[9];
$subject11  = $m_subject[10];
$subject12  = $m_subject[11];
$subject13  = $m_subject[12];
$subject14  = $m_subject[13];
$subject15  = $m_subject[14];
$subject16  = $m_subject[15];
$subject17  = $m_subject[16];
$subject18  = $m_subject[17];
$subject19  = $m_subject[18];
$subject20  = $m_subject[19];
?>
<? 
	$a_file_link1 = str_replace("<a", "<a onfocus=blur()",$a_file_link1); 
	$a_file_link2 = str_replace("<a", "<a onfocus=blur()",$a_file_link2);
 ?>
<script language="javascript">
function view(what) {  
var imgwin = window.open("",'WIN','scrollbars=no,status=no,toolbar=no,resizable=1,location=no,menu=no,width=20,height=20');  
imgwin.focus();  
imgwin.document.open();  
imgwin.document.write("<html>");  
imgwin.document.write("<head>");  
imgwin.document.write("<title>ǥ������</title>");  

imgwin.document.write("<sc"+"ript>\n");  
imgwin.document.write("function resize() {\n");  
imgwin.document.write("pic = document.il;\n");  
//imgwin.document.write("alert(eval(pic).height);\n");  
imgwin.document.write("if (eval(pic).height) { var name = navigator.appName\n");  
imgwin.document.write("  if (name == 'ǥ������') { myHeight = eval(pic).height + 0; myWidth = eval(pic).width + 0;\n");  // 40 12
imgwin.document.write("  } else { myHeight = eval(pic).height + 60; myWidth = eval(pic).width; }\n");  // 9
imgwin.document.write("  clearTimeout();\n");  
imgwin.document.write("  var height = screen.height;\n");  
imgwin.document.write("  var width = screen.width;\n");  
imgwin.document.write("  var leftpos = width / 2 - myWidth / 2;\n");  
imgwin.document.write("  var toppos = height / 2 - myHeight / 2; \n");  
imgwin.document.write("  self.moveTo(leftpos, toppos);\n");  
imgwin.document.write("  self.resizeTo(myWidth, myHeight);\n");  
imgwin.document.write("}else setTimeOut(resize(), 100);}\n");  
imgwin.document.write("</sc"+"ript>");  

imgwin.document.write("</head>");  
imgwin.document.write('<body topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bgcolor="#FFFFFF">');  
imgwin.document.write('<table border=0 cellpadding=5 cellspacing=0 width=100%><tr><td><span style=font-size:9pt;><font color=#FF6600>��</font> <font color=blue>*CLICK TO CLOSE.</font></span></td></tr></table>');  
imgwin.document.write("<a href=# onclick=window.close() onfocus=this.blur()><img border=0 src="+what+" xwidth=100 xheight=9 name=il onload='resize();'></a>");  
imgwin.document.write("</body>");  
imgwin.document.close();  
}  

function hidestatus(){
window.status=''
return true
}
if (document.layers)
document.captureEvents(Event.MOUSEOVER | Event.MOUSEOUT)
document.onmouseover=hidestatus
document.onmouseout=hidestatus
</script>


<table border=0 width=<?=$width?> cellspacing=1 cellpadding=5 bgcolor=cccccc>
<tr><td valign=top bgcolor=f7f7f7>
<table border=0 width=100% height=100% cellspacing=0 cellpadding=3 style=table-layout:fixed>
<col width= align=right></col><col width=500 style='padding-left:5px;'></col>

<tr>
  <td colspan=2 align=left style='padding-left:5px;'><br>
  <table border=0 cellspacing=0 cellpadding=0 width=98%><tr><td><b>Book Information #1</b></td>
  <td align=right><a href="#[å�Ұ�]">[å�Ұ�]</a> <a href="#[������ �Ұ�]">[������ �Ұ�]</a> <a href="#[åǥ����]">[åǥ����]</a> <a href="#[���ǻ� ����]">[���ǻ� ����]</a> <a href="#[���� ����]">[���� ����]</a></td></tr></table>
 <hr size="2" width="98%" noshade color="#999999"></td>
</tr>

<tr>
  <td colspan=2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><font color=#FF9900><span style="font-size:12pt;"><?=$subject1?></span></font></b>
  <?if($subject15=="1"){echo "<img src=$dir/images/1.gif border=0>";}else{echo "";}?>
  <?if($subject16=="1"){echo "<img src=$dir/images/2.gif border=0>";}else{echo "";}?>
  <?if($subject17=="1"){echo "<img src=$dir/images/3.gif border=0>";}else{echo "";}?>
  </td>
</tr>
<tr>
  <td colspan=2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$subject2?></td>
</tr>

<tr>
  <td colspan=2>
  <table border=0 width=100% cellspacing=0 cellpadding=0>
  <col width=150 align=right></col><col width=100% style='padding-left:5px;'></col>
  <tr>
  	<td valign=top>
  			<table border=0 cellspacing=0 cellpadding=0>
  			  <tr>
  			  	 	<td bgcolor=#f7f7f7 valign=top>
 					 			<table border=0 width=150 height=200 cellspacing=1 cellpadding=0 bgcolor=#666666>
 					 			  <tr>
  								  	 	<td bgcolor=#f7f7f7 align=center width=50%>
  								  	 		<div id=good_pre></div>
<?  if($data[file_name1])  {  ?>  <?  }  else  {  ?>  <span><img src=<?=$dir?>/noscreenshot.gif></span>  <?  }  ?> 
<?  if($data[file_name1])  {  ?>  <span><a href="javascript:view('<?=$data[file_name1]?>')" onfocus="this.blur()">  <img src=<?=$data[file_name1]?> width=150 height=180 border=0></a><br>  <table cellspacing=0 cellpadding=0><tr><td height=3></td></tr></table>  <a href="javascript:view('<?=$data[file_name1]?>')" onfocus="this.blur()">[�ڼ�������]</a>   <?  }  else  {  ?>  <?  }  ?>
<?  if($data[file_name2])  {  ?>  <span><a href="javascript:view('<?=$data[file_name2]?>')" onfocus="this.blur()">[�ٸ�����]</a></span>  <?  }  else  {  ?>  <?  }  ?>  
  								  	 	</td>
								  </tr>	
							  </table>  			  	 	
  			  	 	
  			  	 	
  			  	 	
  			  	 	</td>
				  </tr>	
			  </table>
  	</td>
  	<td>
  			<table border=0 width=95% height=205 cellspacing=1 cellpadding=0 bgcolor=#666666>
  			<col width=60 align=right style='padding-right:5px;'></col><col style='padding-left:5px;' width= ></col>
<tr>
  <td bgcolor=#f7f7f7>��&nbsp;&nbsp;&nbsp;��</td>
  <td bgcolor=#f7f7f7><?=$subject3?></td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>��&nbsp;&nbsp;&nbsp;��</td>
  <td bgcolor=#f7f7f7><?=$subject4?></td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>�ǸŰ�</td>
  <td bgcolor=#f7f7f7><font color="red"><?=$subject5?>��</font></td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>������</td>
  <td bgcolor=#f7f7f7><font color="red"><?=$subject6?>%</font></td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>���ǻ�</td>
  <td bgcolor=#f7f7f7><?=$subject7?></td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>������</td>
  <td bgcolor=#f7f7f7><?=$subject8?>��</td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>ũ&nbsp;&nbsp;&nbsp;��</td>
  <td bgcolor=#f7f7f7><?=$subject9?></td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>������</td>
  <td bgcolor=#f7f7f7><?=$subject10?></td>
</tr>

<tr>
  <td bgcolor=#f7f7f7>ISBN</td>
  <td bgcolor=#f7f7f7><a href="javascript:view('http://www.aladdin.co.kr/Cover/<?=$subject11?>_1.gif')" onfocus="this.blur()"><font color="#4715F7"><?=$subject11?></font></a></td>
</tr>
			  </table>  	
  	</td>
  </tr>	
  </table>
  </td>
</tr>

<tr>
  <td bgcolor=#f7f7f7 colspan=2 align=right><?=$subject18?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?  if($data[sitelink1])  {  ?>  <span>  <a href=<?=$data[sitelink1]?> target=blank" onfocus="this.blur()"><img src=<?=$dir?>/images/buynow.gif border=0></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>  <?  }  else  {  ?>  <?  }  ?>  </td>
</tr>

<tr>
  <td colspan=2>
  <table border=0 cellspacing=0 cellpadding=0 width=100%>
  <col width=100></col><col width= style='padding-left:5px;'></col>
 <tr>
  <td colspan=2 align=left style='padding-left:5px;'><br><b>Book Information #2</b><br>  
  <hr size="2" width="98%" noshade color="#999999"></td>
</tr>

<tr>
  <td valign=top><font color="#4715F7"><b><a name="[å�Ұ�]">[å�Ұ�] </a></b></font></td>
  <td><br>
  <?=$subject12?></td>
</tr>
<tr>
  <td valign=top><font color="#4715F7"><b><a name="[������ �Ұ�]">[������ �Ұ�]</a></b></font></td>
  <td><br>
  <?=$subject13?></td>
</tr>
<tr>
  <td valign=top><font color="#4715F7"><b><a name="[åǥ����]">[åǥ����]</a></b></font></td>
  <td><br>
  <?=$subject14?></td>
</tr>


<tr>
  <td colspan=2 align=left style='padding-left:5px;'><br><b>Review</b><br>  
  <hr size="2" width="98%" noshade color="#999999"></td>
</tr>

<tr>
  <td valign=top><font color="#4715F7"><b><a name="[���ǻ� ����]">[���ǻ� ����] </a></font></b></td>
  <td><br><?=$data[sitelink2]?></td>
</tr>

<?
  if($data[memo])
  {
  ?>
  <span>
<tr>
  <td colspan=2 align=left style='padding-left:5px;'><br><b>Review INDEX</b><br>  
  <hr size="2" width="98%" noshade color="#999999"></td>
</tr>  
  <tr>
  <td colspan=2>
	<table border=0 width=100% height=100% cellspacing=0 cellpadding=0 style=table-layout:fixed>
	<col width=100 ></col><col width=95% style='padding-left:5px;'></col>
  	<tr>
		  <td valign=top><font color="#4715F7"><b><a style='cursor:hand' onclick='toggle(index);' name="[���� ����]">[���� ����] </a></font></b>
		  <br><a style='cursor:hand' onclick='toggle(index);'>- ����/�ݱ� -</a></td>
  		</td>
  		<td align=right>
  		<span id='index' style='display:none;width:100%;filter:blendTrans(Duration=0.5)'>
  		<br><?=$memo?>
			</span> 
  		</td>
  	</tr>
  </table>
  </td>
</tr>
  </span>
  <?
  }
  else
  {
  ?>
  <?
  }
  ?>
</table>

  </td>
</tr>

<tr><td height=10 colspan=2></td></tr>
</table>
</td></tr>
</table>
<br>

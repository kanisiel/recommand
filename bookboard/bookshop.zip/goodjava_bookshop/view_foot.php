<?=$hide_comment_end?>

<table border=0 width=<?=$width?> cellspacing=0 cellpadding=0>
<tr>
<td height=5></td>
</tr>
<tr>
<td colspan=2 height=1 bgcolor=#cdcdcd></td>
</tr>
<tr>
<td height=5></td>
</tr>
<tr>
<td>
<?=$a_modify?><img src=<?=$dir?>/images/edit.gif border=0></a>
<?=$a_delete?><img src=<?=$dir?>/images/del.gif border=0></a>
</td>
<td align=right>
<?=$a_list?><img src=<?=$dir?>/images/list.gif border=0></a>
<?=$a_write?><img src=<?=$dir?>/images/write.gif border=0></a>
</td>
</tr>
</table>

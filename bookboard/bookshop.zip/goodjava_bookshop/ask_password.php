<br><br><br>
<div align=center>
<table border=0 width=300 cellspacing=1 cellpadding=5 bgcolor=cccccc>
<tr><td valign=top bgcolor=f7f7f7>


<table border=0 width=100% height=100% cellspacing=0 cellpadding=3 style=table-layout:fixed>
<form method=post name=delete action=<?=$target?>>
<input type=hidden name=page value=<?=$page?>>
<input type=hidden name=id value=<?=$id?>>
<input type=hidden name=no value=<?=$no?>>
<input type=hidden name=select_arrange value=<?=$select_arrange?>>
<input type=hidden name=desc value=<?=$desc?>>
<input type=hidden name=page_num value=<?=$page_num?>>
<input type=hidden name=keyword value="<?=$keyword?>">
<input type=hidden name=category value="<?=$category?>">
<input type=hidden name=sn value="<?=$sn?>">
<input type=hidden name=ss value="<?=$ss?>">
<input type=hidden name=sc value="<?=$sc?>">
<input type=hidden name=mode value="<?=$mode?>">
<input type=hidden name=c_no value=<?=$c_no?>>
<tr>
<td colspan=2 height=1 bgcolor=#cdcdcd></td>
</tr>
<tr>
<td align=center height=40><BR><?=$title?><BR><BR><?=$input_password?><BR><BR></td></td>
</tr>
<tr>
<td colspan=2 height=1 bgcolor=#cdcdcd></td>
</tr>

<tr>
<td colspan=2 align=center height=60 valign=bottom>
<input type=image border=0 src=<?=$dir?>/images/ok.gif onfocus=blur()>
<a href=# onclick=history.go(-1) onfocus=blur()><img src=<?=$dir?>/images/back.gif border=0></a>
</td>
</tr>
<tr>
<td colspan=2 height=1 bgcolor=#cdcdcd></td>
</tr>
</table>

</td></tr>
</table>

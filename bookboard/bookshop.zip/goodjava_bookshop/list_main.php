<script language="javascript">
function view(what) {  
var imgwin = window.open("",'WIN','scrollbars=no,status=no,toolbar=no,resizable=1,location=no,menu=no,width=20,height=20');  
imgwin.focus();  
imgwin.document.open();  
imgwin.document.write("<html>");  
imgwin.document.write("<head>");  
imgwin.document.write("<title>ǥ������</title>");  

imgwin.document.write("<sc"+"ript>\n");  
imgwin.document.write("function resize() {\n");  
imgwin.document.write("pic = document.il;\n");  
//imgwin.document.write("alert(eval(pic).height);\n");  
imgwin.document.write("if (eval(pic).height) { var name = navigator.appName\n");  
imgwin.document.write("  if (name == 'ǥ������') { myHeight = eval(pic).height + 0; myWidth = eval(pic).width + 0;\n");  // 40 12
imgwin.document.write("  } else { myHeight = eval(pic).height + 60; myWidth = eval(pic).width; }\n");  // 9
imgwin.document.write("  clearTimeout();\n");  
imgwin.document.write("  var height = screen.height;\n");  
imgwin.document.write("  var width = screen.width;\n");  
imgwin.document.write("  var leftpos = width / 2 - myWidth / 2;\n");  
imgwin.document.write("  var toppos = height / 2 - myHeight / 2; \n");  
imgwin.document.write("  self.moveTo(leftpos, toppos);\n");  
imgwin.document.write("  self.resizeTo(myWidth, myHeight);\n");  
imgwin.document.write("}else setTimeOut(resize(), 100);}\n");  
imgwin.document.write("</sc"+"ript>");  

imgwin.document.write("</head>");  
imgwin.document.write('<body topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" bgcolor="#FFFFFF">');  
imgwin.document.write('<table border=0 cellpadding=5 cellspacing=0 width=100%><tr><td><span style=font-size:9pt;><font color=#FF6600>��</font> <font color=blue>*CLICK TO CLOSE.</font></span></td></tr></table>');  
imgwin.document.write("<a href=# onclick=window.close() onfocus=this.blur()><img border=0 src="+what+" xwidth=100 xheight=9 name=il onload='resize();'></a>");  
imgwin.document.write("</body>");  
imgwin.document.close();  

}  
</script>
<?
$m_subject = explode("|",$subject);
$subject1   = $m_subject[0];
$subject2		= $m_subject[1];
$subject3  = $m_subject[2];
$subject4  = $m_subject[3];
$subject5  = $m_subject[4];
$subject6  = $m_subject[5];
$subject7  = $m_subject[6];
$subject8  = $m_subject[7];
$subject9  = $m_subject[8];
$subject10  = $m_subject[9];
$subject11  = $m_subject[10];
$subject12  = $m_subject[11];
$subject13  = $m_subject[12];
$subject14  = $m_subject[13];
$subject15  = $m_subject[14];
$subject16  = $m_subject[15];
$subject17  = $m_subject[16];
$subject18  = $m_subject[17];
$subject19  = $m_subject[18];
$subject20  = $m_subject[19];

 unset($s_info);
 $_srcname="$dir/noscreenshot.gif";
 $_xsize=90;
 $_ysize=100;
 $_alink="";
 if($data[file_name1])
 {
  $s_info = @getimagesize($data[file_name1]);

	if($s_info[2]>0&&$s_info[2]<4)
	{
		$_xsize = $s_info[0];
		if($_xsize>$_hsize) $_xsize=$_hsize;
		$_srcname = $data[file_name1];
		$_alink="<a href=javascript:void(window.open('$dir/show_pic.php?file=$data[file_name1]','$data[no]','width=$s_info[0],height=$s_info[1],resizable=yes,toolbars=no,scrollbars=auto')) onfocus=blur()>";
	}
 }

 $_x ++;
 $_temp = $_x % 1;		// ����Ʈ��Ͽ� ��µ� �̹����� �������

?>
<?if($_temp==1){?>
<tr>
<?}?>
<td valign=top align=center>

<Table border=0 cellspacing=0 cellpadding=0 width=<?=$width?> >  
<tr align=center >
	<td width=90 align=center style=padding:1px valign=top><?=$_alink?><img src=<?=$_srcname?> border=0 width=80 height=98></a></td>
	<td valign=top>
			<Table border=0 cellspacing=0 cellpadding=0 width=100% height=100>
			<col width=60></col><col width=></col>
			<tr>
					<td style='word-break:break-all;' colspan="2">
						<b><span style="font-size:12pt;color=#FF9900"><?=$number?>. <?=$subject1?></span></b> <font style=font-family:����;font-size:6pt><?=$comment_num?></font> <?=$hide_category_start?>[<?=$category_name?>] <?=$hide_category_end?>
					  <?if($subject15=="1"){echo "<img src=$dir/images/1.gif border=0>";}else{echo "";}?>
					  <?if($subject16=="1"){echo "<img src=$dir/images/2.gif border=0>";}else{echo "";}?>
					  <?if($subject17=="1"){echo "<img src=$dir/images/3.gif border=0>";}else{echo "";}?>
					</td>
			</tr>
    <tr>
        <td class=t7><?=$hide_cart_start?><?=$a_modify?>Edit</a><?=$hide_cart_end?></td>
        <td>
            <?=$subject3?>
        </td>
    </tr>
    <tr>
        <td class=t7><?=$hide_cart_start?><?=$a_delete?>Delete</a><?=$hide_cart_end?></td>
        <td>
            <font color="#000000">����-<?=$subject4?>��</font>, �ǸŰ�-<font color="red"><?=$subject5?>��</font>, ������-<font color="red"><?=$subject6?>%</font>
        </td>
    </tr>
    <tr>
        <td class=t7><nobr><?=$hide_cart_start?>Read : <?=$hit?><?=$hide_cart_end?></nobr></td>
        <td>
        		<?=$subject7?>, <?=$subject8?>��, <?=$subject9?>, <?=$subject10?>, ISBN(<a href="javascript:view('http://www.aladdin.co.kr/Cover/<?=$subject11?>_1.gif')" onfocus="this.blur()"><font color="#4715F7"><?=$subject11?></font></a>)
        		
<?
  if($data[sitelink1])
  {
  ?>
  <span><a href=<?=$data[sitelink1]?> target=blank" onfocus="this.blur()"><font color=blue>[�ٷα���]</font></a></span>
  <?
  }
  else
  {
  ?>
  <?
  }
  ?>         		
        </td>
    </tr>								
			</table>	
	</td>
</tr>
<tr>
<td height=3 colspan=2></td>
</tr>
<tr>
<td height=1 bgcolor=#CDCDCD colspan=2></td>
</tr>


</table>

</td>
<?if(!$_temp){?>
</tr>
<?
	}
?>
